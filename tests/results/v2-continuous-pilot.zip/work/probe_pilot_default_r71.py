"""Discovery only with ordinary host settings, no generation or installation mutation."""
import json
import v2_benchmark as base

out=base.OUT/'continuous-pilot-r71'
project=base.OUT/'business-pilot-r70/package-install/project'
args=['-c','web_search="disabled"','-c','sandbox_workspace_write.network_access=false']
result=base.probe(project,args,out/'default-discovery.json')
def skills(v):
 if isinstance(v,dict):
  if v.get('name')=='intent-compiler' and 'path' in v:yield {k:v.get(k) for k in ['name','path','scope','enabled']}
  for child in v.values():yield from skills(child)
 elif isinstance(v,list):
  for child in v:yield from skills(child)
found=list(skills(result))
(out/'default-discovery-summary.json').write_text(json.dumps({'project':str(project),'arguments':args,'sameNameSkills':found,'modelCalls':0},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(found,ensure_ascii=False,indent=2))
