"""Reconstruct published evidence and execute only its offline independent checks."""
import json,subprocess,sys,zipfile
from pathlib import Path
from v2_continuous_pilot import OUT,REPO

dest=Path('C:/Users/Dawn/Documents/Codex/r71-evidence-replay')
assert dest.resolve().is_relative_to(Path('C:/Users/Dawn/Documents/Codex').resolve())
dest.mkdir(exist_ok=False)
with zipfile.ZipFile(REPO/'tests/results/v2-continuous-pilot.zip') as z:
 for n in z.namelist():assert (dest/n).resolve().is_relative_to(dest.resolve())
 z.extractall(dest)
commands=[['work/audit_continuous_pilot.py','--selfcheck'],['work/audit_continuous_pilot.py'],
 ['work/intent-compiler-skill/tests/test_trial_package.py'],['work/intent-compiler-skill/commercial/revenue_model.py']]
results=[]
for args in commands:
 r=subprocess.run([sys.executable,'-X','utf8']+args,cwd=dest,capture_output=True,text=True,encoding='utf-8',timeout=60)
 results.append({'argv':args,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode:break
if all(x['exitCode']==0 for x in results):
 data=json.loads((dest/'outputs/intent-compiler-v2/continuous-pilot-r71/independent-files-progress.json').read_text(encoding='utf-8'))
 assert len(data)==3 and all(len(v['stages'])==6 for v in data.values())
 assert all(s['sourceBytesPreserved'] for v in data.values() for s in v['stages'])
 assert all(not z['privateFindings'] and all(l['exists'] for l in z['relativeLinks']) for v in data.values() for z in v['finalArchives'].values())
 for n in ['revenue-results.json','revenue-scenarios.csv','revenue-sensitivity.csv','revenue-support-thresholds.csv']:
  assert (dest/'work/intent-compiler-skill/commercial'/n).read_bytes()==(REPO/'commercial'/n).read_bytes()
report={'root':str(dest),'commands':results,'modelCalls':0,'sourceSnapshotStages':18,
 'allChecksPass':len(results)==4 and all(x['exitCode']==0 for x in results),
 'limits':'Reconstruction on the same Windows/Python host, not model reruns, a second host, a blinded reviewer or external users.'}
(OUT/'replay-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
