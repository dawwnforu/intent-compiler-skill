"""One exposed onboarding run: real ZIP install, same-name user skill retained."""
import json
import shutil
from pathlib import Path
import zipfile
import v2_benchmark as base

OUT=base.OUT/'continuous-pilot-r71'
folder=OUT/'onboarding';folder.mkdir()
workspace=folder/'workspace';workspace.mkdir()
protocol=json.loads((OUT/'onboarding-protocol.json').read_text(encoding='utf-8'))
package=OUT/'intent-compiler-local-pilot-r71.zip'
copied=[]
with zipfile.ZipFile(package) as z:
 for n in z.namelist():
  if n.startswith('skill/intent-compiler/'):target=workspace/'.agents/skills'/n.removeprefix('skill/')
  elif n.startswith('sample/'):target=workspace/n.removeprefix('sample/')
  else:continue
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(n));copied.append(n)
  if n.startswith('skill/intent-compiler/'):
   assert target.read_bytes()==(OUT/'snapshot'/n.removeprefix('skill/intent-compiler/')).read_bytes()
args=base.options('A')[2:]
args=[s.replace('web_search="live"','web_search="disabled"').replace('sandbox_workspace_write.network_access=true','sandbox_workspace_write.network_access=false') for s in args]
assert not any('skills.config' in s for s in args)
with base.run_record(folder) as status:
 status['stage']='discovery'
 discovered=base.probe(workspace,args,folder/'skills.json')
 def matches(v):
  if isinstance(v,dict):
   if v.get('name')=='intent-compiler' and v.get('enabled'):yield v['path']
   for x in v.values():yield from matches(x)
  elif isinstance(v,list):
   for x in v:yield from matches(x)
 paths=list(matches(discovered));assert any(str(workspace) in p for p in paths) and any('.codex' in p for p in paths)
 env=base.execution_environment(folder/'environment.json')
 command=['codex','exec','--ignore-user-config','--skip-git-repo-check','--json','--ephemeral','-m','gpt-6.1-sol','-o',str(folder/'response.md')]+args+['-s','workspace-write','-C',str(workspace),'-']
 (folder/'invocation.json').write_text(json.dumps({'argv':command,'stdin':protocol['message'],'installedFrom':str(package),'copied':copied,'sameNameEnabled':paths},ensure_ascii=False,indent=2),encoding='utf-8')
 base.execute(command,protocol['message'],folder,status,env,240,cwd=workspace)
 print(json.dumps(status),flush=True)
