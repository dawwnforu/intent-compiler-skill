"""Run the four current CI commands once; these are not behavior/host tests."""
import json,subprocess,sys
from v2_continuous_pilot import OUT,REPO

commands=[['tests/check_repository.py'],['tests/test_html_scripts_candidate.py'],
 ['tests/test_trial_package.py'],['commercial/revenue_model.py']]
results=[]
for args in commands:
 r=subprocess.run([sys.executable,'-X','utf8']+args,cwd=REPO,capture_output=True,text=True,encoding='utf-8',timeout=60)
 results.append({'argv':args,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode:break
status='pass' if len(results)==4 and all(x['exitCode']==0 for x in results) else 'fail'
(OUT/'static-checks.json').write_text(json.dumps({'status':status,'commands':results,'scope':'Static/local component CI checks only; no model/host/user compatibility claim'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':status,'commands':results},ensure_ascii=False,indent=2))
