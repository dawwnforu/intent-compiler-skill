import json, pathlib, subprocess, sys, time, threading, queue

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / 'outputs' / 'skill-evaluation-20261011'
SKILL = pathlib.Path('C:/Users/Dawn/.codex/skills/intent-compiler/SKILL.md')
inventory = json.loads((ROOT/'work/skill-inventory.json').read_text(encoding='utf-8'))['result']['data'][0]['skills']
def options(arm):
    settings = [{'path':s['path'].replace('\\','/'),'enabled':arm=='B' and s['name']=='intent-compiler'} for s in inventory]
    value = 'skills.config=[' + ','.join('{path='+json.dumps(s['path'])+',enabled='+str(s['enabled']).lower()+'}' for s in settings) + ']'
    args = ['-c',value,'-c','model_reasoning_effort="low"','-c','project_doc_max_bytes=0','-c','web_search="live"','-c','windows.sandbox="elevated"','-c','sandbox_workspace_write.network_access=true']
    for pid in sorted({s['pluginId'] for s in inventory if s.get('pluginId')}):
        args += ['-c','plugins.'+json.dumps(pid)+'.enabled=false']
    return args

PROMPTS = {
 'mod':'我想给一个游戏做个 mod，但我完全不会写代码。可以用什么平台和方式？有没有低代码、能直接跑脚本的办法？',
 'docs':'我们项目的文档很乱，我没做过知识库，也不懂那些专有名词。请你直接读我给的文件，把问题分类整理好，再告诉我后面怎么弄。文件都在当前目录的 inputs 文件夹里。',
 'robot':'我不会建模，但想做一个圆圆的小机器人，能转头挥手，最后能放进网页里。你帮我弄出来。'
}
BOUNDARY = '\n\n本次只在当前工作目录内创建成果；可以读取已安装工具和已启用 Skill，查询公开资料。不要读取其他会话、测试目录或私人文件。不要安装软件或依赖、购买服务、上传文件、公开发布或修改真实项目。使用现有工具完成能完成的部分。'

def prepare():
    OUT.mkdir(parents=True,exist_ok=True)
    for case in PROMPTS:
        for arm in ['A','B']:
            folder=OUT/case/arm; folder.mkdir(parents=True,exist_ok=True)
            (folder/'workspace').mkdir(exist_ok=True)
            (folder/'request.txt').write_text(PROMPTS[case]+BOUNDARY,encoding='utf-8')
            if case=='docs':
                inp=folder/'workspace'/'inputs'; inp.mkdir(exist_ok=True)
                (inp/'01-会议记录.md').write_text('# 10月1日项目会\n项目：松果办公助手。计划10月20日上线，负责人林青。\n试用期14天。客服问题由陈晨处理，目标2个工作日内回复。\n上线前需要完成帮助文档，王宁负责。\n',encoding='utf-8')
                (inp/'02-客服FAQ.md').write_text('# 客服常见问题\n试用期14天。客服问题由陈晨处理，目标2个工作日内回复。\n用户问：是否支持导出？答：支持导出CSV。\n',encoding='utf-8')
                (inp/'03-营销草稿.txt').write_text('松果办公助手营销文案草稿，未标注日期。\n10月25日正式上线，免费试用30天。\n支持Excel文件导出。\n定价：待定。\n',encoding='utf-8')
                (inp/'04-补充说明.pdf').write_bytes(b'%PDF-1.7\n% truncated fixture\n1 0 obj\n<< /Type /Catalog >>\n')
    (OUT/'protocol.json').write_text(json.dumps({'model':'gpt-6.1-sol','effort':'low','replicates':1,'arms':{'A':'Intent Compiler disabled','B':'Intent Compiler enabled and explicitly invoked'},'other_skills':'disabled equally','shared_boundary':BOUNDARY,'commit':'6bcc84a5647360d6a1e0482edb5e86e755d86a2c','limitations':['single trial per arm, no statistical significance','single-turn requests; mod game is intentionally unspecified','CLI tool environment, not full desktop connectors']},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Prepared identical inputs and protocol.')

def probe(arm):
    p=subprocess.Popen(['codex','app-server','--stdio']+options(arm),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8')
    q=queue.Queue(); threading.Thread(target=lambda:[q.put(x) for x in p.stdout],daemon=True).start()
    def rpc(n,method,params):
        p.stdin.write(json.dumps({'id':n,'method':method,'params':params})+'\n');p.stdin.flush()
        while True:
            obj=json.loads(q.get(timeout=30))
            if obj.get('id')==n:return obj
    try:
        rpc(1,'initialize',{'clientInfo':{'name':'intent_eval','version':'1.0'}})
        result=rpc(2,'skills/list',{'cwds':[str(OUT/'mod'/arm)],'forceReload':True})
        (OUT/f'skills-{arm}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        enabled=[s['name'] for s in result['result']['data'][0]['skills'] if s['enabled']]
        assert enabled == ([] if arm=='A' else ['intent-compiler']),enabled
        print(arm,'enabled skills:',enabled)
    finally:p.terminate()

def run(case,arm):
    folder=OUT/case/arm
    prompt=(folder/'request.txt').read_text(encoding='utf-8')
    if arm=='B':prompt='$intent-compiler\n\n'+prompt
    args=['codex','exec','--ignore-user-config','--ephemeral','--skip-git-repo-check','--json','-m','gpt-6.1-sol','-s','workspace-write','-C',str(folder/'workspace'),'-o',str(folder/'response.md')]+options(arm)+['-']
    (folder/'invocation.json').write_text(json.dumps({'argv':args,'stdin':prompt},ensure_ascii=False,indent=2),encoding='utf-8')
    start=time.time()
    with (folder/'events.jsonl').open('w',encoding='utf-8') as stdout,(folder/'stderr.txt').open('w',encoding='utf-8') as stderr:
        p=subprocess.run(args,input=prompt,text=True,encoding='utf-8',stdout=stdout,stderr=stderr,timeout=1200)
    meta={'exit_code':p.returncode,'wall_seconds':round(time.time()-start,2)}
    (folder/'run.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(case,arm,meta)

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='probe':probe(sys.argv[2])
    else:run(sys.argv[2],sys.argv[3])
