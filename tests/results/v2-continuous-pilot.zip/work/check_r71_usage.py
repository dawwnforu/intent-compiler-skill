"""Read token metadata only from the three exact sessions created by this study."""
import json
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent.parent
out=root/'outputs/intent-compiler-v2/continuous-pilot-r71'
sessions=Path('C:/Users/Dawn/.codex/sessions/2026/10/19')
report={}
for arm in ['G','V2','A']:
 folder=out/'runs'/arm
 thread=json.loads((folder/'turn2/invocation.json').read_text(encoding='utf-8'))['thread_id']
 files=subprocess.check_output(['rg','--files',str(sessions),'-g',f'*{thread}.jsonl'],text=True).splitlines()
 assert len(files)==1,'Exact study session log not uniquely located'
 path=Path(files[0]).resolve();assert path.is_relative_to(sessions.resolve()) and thread in path.name
 usage=[]
 for line in path.read_text(encoding='utf-8').splitlines():
  e=json.loads(line);payload=e.get('payload',{})
  if e.get('type')=='event_msg' and payload.get('type')=='token_count' and payload.get('info'):
   usage.append(payload['info']['total_token_usage'])
 cli=[]
 for n in range(1,7):
  events=[json.loads(l) for l in (folder/f'turn{n}/events.jsonl').read_text(encoding='utf-8').splitlines()]
  cli.append([e['usage'] for e in events if e['type']=='turn.completed'][0])
 keys=['input_tokens','cached_input_tokens','output_tokens']
 assert all(all(u[k]==usage[-1][k] for k in keys) for u in cli[-1:])
 assert all(any(all(c[k]==u[k] for k in keys) for u in usage) for c in cli)
 deltas=[{k:c[k]-(cli[i-1][k] if i else 0) for k in keys} for i,c in enumerate(cli)]
 assert all(n>=0 for d in deltas for n in d.values())
 report[arm]={'threadId':thread,'metadataRecords':len(usage),'cliEachTurnMatchesHostCumulative':True,
   'sessionEndReportedTotal':{k:cli[-1][k] for k in keys},'incrementsByTurn':deltas,
   'source':'token_count.info.total_token_usage in this study session, not transcript content or other sessions'}
(out/'usage-semantics.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
