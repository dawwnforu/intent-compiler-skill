"""Archive this cycle only; no sessions, credentials or participant records."""
import json
from pathlib import Path
import zipfile
from v2_continuous_pilot import OUT,REPO

ROOT=Path(__file__).resolve().parent.parent
target=REPO/'tests/results/v2-continuous-pilot.zip'
files={}
def add(path):
 if path.is_file() and '__pycache__' not in path.parts and path.suffix not in ['.pyc','.log'] and '.agents' not in path.parts:
  assert 'local-feedback' not in path.parts
  files[path.relative_to(ROOT).as_posix()]=path
for path in OUT.rglob('*'):add(path)
for name in ['v2_benchmark.py','run_eval.py','skill-inventory.json','v2_business_pilot.py','audit_business_pilot.py',
 'v2_continuous_pilot.py','audit_continuous_pilot.py','check_r71_usage.py','r71_onboarding.py','r71_final_install.py',
 'r71_presentation.py','diagnose_claude_r71.py','probe_pilot_default_r71.py','build_r71_evidence.py',
 'replay_r71_evidence.py','record_r71.py','check_r71_repository.py']:
 add(ROOT/'work'/name)
for directory in ['pilot','commercial','skills/intent-compiler']:
 for path in (REPO/directory).rglob('*'):add(path)
for name in ['LICENSE','.codex-plugin/plugin.json','.claude-plugin/plugin.json','tests/test_trial_package.py']:
 add(REPO/name)
for name in ['client.zip','internal.md']:
 add(OUT.parent/'business-pilot-r70/runs/r70/handoff/V2/workspace/outputs'/name)
replay='''# R71 evidence replay (not a Git checkout or a trial installer)

Extract into a new empty directory. Files retain their original relative tree.
Open outputs/intent-compiler-v2/continuous-pilot-r71/ux/compare.html for a single
entry to all three actual client deliveries and before/after attachment examples.
Only synthetic business data is included. No participant, credential, raw account
session transcript or global config is bundled. Skill copies under .agents are
omitted after actual byte-identity checks; the frozen snapshot is included.

With Python3.12, run from the extracted root, offline and without model calls:

    python work/audit_continuous_pilot.py --selfcheck
    python work/audit_continuous_pilot.py
    python work/intent-compiler-skill/tests/test_trial_package.py
    python work/intent-compiler-skill/commercial/revenue_model.py

Inspect outputs/intent-compiler-v2/continuous-pilot-r71/independent-files-progress.json
and compare its stages/finalArchives with independent-files-final.json. All18
sourceBytesPreserved values and all final relative links should be true, fixture
privateFindings empty. This is data/recipient-byte inspection, not model replication.
Windows original CRLF is explicit in the checker, independent of replay OS.

For actual browser reinspection, serve the included ux directory using Python's
http.server bound to127.0.0.1 on an available port. Open photo-fixed/index.html
and its reply link; compare transfer-before/index.html and transfer-after/index.html
links. Screenshots/AX and manual-review.json retain observed original operations.
This does not verify local file double-click, native print, another browser or users.

protocol.json contains frozen six-message inputs, acceptance, budget and original
runner; runner-executed.py retains the pre-generation temp-dir self-check adjustment.
Each arm has prompts/argv/events/stderr/run.json and after-turn1..6 snapshots.
Original recipient ZIPs, intermediate misses and failed command records are retained.
costs.json uses verified session-end totals; costs-initial-unverified-sums.json is
explicitly superseded. usage-semantics.json extracts only token metadata from the
three exact owned sessions; check_r71_usage.py needs those original host logs and
is not an offline requirement. Tokens are not a cash invoice.

onboarding is one exposed regression, not a fourth arm. final-install is discovery
only: its generic process_started=false means no model launcher, not an absent
app-server probe; skills.json and24 copied-file checks record real discovery.
The final trial archive has updated docs but exactly the same24 runtime files as
the installed precheck archive. Both archives are retained, never silently swapped.

Do not run archived generated build scripts or overwrite old experiments. For a
new behavioral study, use a real repository checkout and a separate output root,
same model/permissions/materials/message order, refreshed host Skill inventory and
the approved launcher. The18-call/240sec-per-turn budget plus at most2 development
calls is not permission to resample until a preferred result. Missing host access
stays unverified. This archive alone is not cross-host compatibility evidence.
'''
manifest={'baseCommit':json.loads((OUT/'protocol.json').read_text(encoding='utf-8'))['baseCommit'],
 'files':sorted(files),'fileCount':len(files),'modelGenerations':19,'realExternalParticipants':0,
 'purpose':'Reproducible internal evidence, not a marketplace package; runtime and MIT unchanged'}
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
 z.writestr('REPLAY.md',replay);z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
 for name,path in files.items():z.write(path,name)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert all(not n.endswith(('.env','.pyc')) and '/local-feedback/' not in n and '/.codex/sessions/' not in n for n in z.namelist())
print(target,len(files),'files',target.stat().st_size,'bytes')
