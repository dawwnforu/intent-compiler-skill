"""Summarize observed evidence, retaining unverified states rather than scoring them."""
import json,zipfile
from pathlib import Path
from v2_continuous_pilot import OUT,REPO

def read(name):return json.loads((OUT/name).read_text(encoding='utf-8-sig'))
costs=read('costs.json');onboard=read('onboarding/run.json')
events=[json.loads(l) for l in (OUT/'onboarding/events.jsonl').read_text(encoding='utf-8').splitlines()]
onboard_usage=next(e['usage'] for e in events if e['type']=='turn.completed')
total={k:sum(v['reportedUsageTotal'][k] for v in costs['arms'].values())+onboard_usage[k] for k in ['input_tokens','cached_input_tokens','output_tokens']}
package=REPO/'pilot/intent-compiler-local-pilot.zip'
with zipfile.ZipFile(package) as z:
 source=json.loads(z.read('SOURCE.json'))
 assert z.read('LICENSE')==(REPO/'LICENSE').read_bytes()
 assert z.read('pilot-log.csv').count(b'\n')==1
summary={'baseCommit':read('protocol.json')['baseCommit'],'runtimeCoreChanged':False,
 'frozenCore':read('frozen-core-check.json'),
 'threeArmComparison':costs,'usageSemantics':read('usage-semantics.json'),
 'manualInspection':read('manual-review.json'),'originalRecipientUx':read('ux/observations.json'),
 'presentationRegressionAndTransfer':read('presentation-check.json'),
 'onboarding':{'run':onboard,'usage':onboard_usage,'independent':read('onboarding-independent.json')},
 'finalInstallation':read('final-install/run.json'),'hostVersions':read('host-versions.json'),
 'claudeRouting':read('claude-routing.json'),'offlineArchiveReplay':read('replay-check.json'),
 'trialPackage':{'path':'pilot/intent-compiler-local-pilot.zip','bytes':package.stat().st_size,'source':source,'participantDataRows':0},
 'totalDevelopmentModelRuns':19,'modelSeconds':round(sum(v['seconds'] for v in costs['arms'].values())+onboard['wall_seconds'],2),
 'reportedTokenTotals':total,'cashInferenceInvoice':None,
 'quotaObservation':{'accountWeeklyUsedBefore':19,'accountWeeklyUsedAfterModelRuns':23,'scope':'Shared account window, not attributable spend or a cash bill'},
 'economicsCheck':read('economics-check.json'),
 'commercialEvidence':{'supportMinutes':'hypothesis, no external measurements','conversionRefundWage':'hypotheses',
   'platformShare':'Agensi terms verified2026-10-19, recheck before launch;70/30 only if channel licensing/delivery clarified',
   'source':'https://www.agensi.io/terms','actualPayout':None},
 'staticChecks':read('static-checks.json') if (OUT/'static-checks.json').exists() else {'status':'pending'},
 'archiveExtensionCheck':read('archive-extension-check.json') if (OUT/'archive-extension-check.json').exists() else None,
 'comparisonEntry':'outputs/intent-compiler-v2/continuous-pilot-r71/ux/compare.html (inside evidence archive)',
 'externalParticipants':0,'realReuse7Days':0,'orders':0,'refunds':0,
 'decision':'Continue repaired Codex free trial with three consented real users; no new core rules, broad benefit claim, host expansion or marketplace submission. Keep real support/adoption/reuse/payment unknown.',
 'limits':['Internal unblinded operator, not independent external users','Single fixed business session per arm, source-authority warning and offline tool policy','Packer fault actually occurs in turn1; no partial external effects','Native local opening/editor/printing and Claude business unverified','Packaging transfer is not model/domain superiority','Original data/old versions preserved; no resampling, official install replacement, PR merge, paid listing or MIT change']}
(REPO/'tests/results/v2-continuous-pilot.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Observed summary written:',summary['modelSeconds'],'model seconds',total,'static',summary['staticChecks'].get('status'))
