"""Read only whitelisted routing metadata; never output credential values."""
import json,os
from pathlib import Path
from urllib.parse import urlsplit
from datetime import datetime,timezone

root=Path(__file__).resolve().parent.parent/'outputs/intent-compiler-v2/continuous-pilot-r71'
models=['ANTHROPIC_MODEL','ANTHROPIC_DEFAULT_SONNET_MODEL','ANTHROPIC_DEFAULT_OPUS_MODEL','ANTHROPIC_DEFAULT_HAIKU_MODEL']
report={'checkedAt':datetime.now(timezone.utc).isoformat(),'source':'Current evaluator parent process environment; no credential/provider changes',
 'baseUrlHostname':urlsplit(os.environ.get('ANTHROPIC_BASE_URL','')).hostname,
 'models':{k:os.environ.get(k) for k in models},
 'credentialPresenceOnly':{k:bool(os.environ.get(k)) for k in ['ANTHROPIC_AUTH_TOKEN','ANTHROPIC_API_KEY']},
 'alternateProviderFlags':{k:os.environ.get(k) for k in ['CLAUDE_CODE_USE_BEDROCK','CLAUDE_CODE_USE_VERTEX','CLAUDE_CODE_USE_FOUNDRY']},
 'observedR70':'Local auth status reported logged in; init resolved deepseek-v4-pro[1M] despite requested sonnet; remote request failed401, before business tool execution.',
 'classification':'Inherited third-party provider/model routing explains the model mismatch. Remote authentication remains failed on that route; exact credential/account cause is not established. Skill discovery succeeded; business behavior and Anthropic Sonnet unverified.',
 'nextAction':'Account owner should choose intended provider and use its normal authentication/configuration workflow; no credentials should be shared here. Then one bounded business run, separately from Codex comparison.',
 'newModelCalls':0}
(root/'claude-routing.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
