"""Install and discover the exact final trial ZIP; no model, no personal changes."""
import json,zipfile
from pathlib import Path
import v2_benchmark as base

out=base.OUT/'continuous-pilot-r71';folder=out/'final-install';folder.mkdir()
project=folder/'project';project.mkdir()
package=base.ROOT/'work/intent-compiler-skill/pilot/intent-compiler-local-pilot.zip'
files=[]
with zipfile.ZipFile(package) as z:
 for n in z.namelist():
  if n.startswith('skill/intent-compiler/'):
   target=project/'.agents/skills'/n.removeprefix('skill/')
   assert target.resolve().is_relative_to(project.resolve())
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(n));files.append(n)
   assert target.read_bytes()==(out/'snapshot'/n.removeprefix('skill/intent-compiler/')).read_bytes()
 assert z.read('pilot-log.csv').count(b'\n')==1
args=['-c','web_search="disabled"','-c','sandbox_workspace_write.network_access=false']
with base.run_record(folder) as status:
 status['stage']='final_package_discovery'
 result=base.probe(project,args,folder/'skills.json')
 def matching(v):
  if isinstance(v,dict):
   if v.get('name')=='intent-compiler' and 'path' in v:yield {k:v.get(k) for k in ['name','path','enabled','scope']}
   for x in v.values():yield from matching(x)
  elif isinstance(v,list):
   for x in v:yield from matching(x)
 matches=list(matching(result));assert any(str(project) in s['path'] and s['enabled'] for s in matches)
 status.update(exit_code=0,files_copied=len(files),model_generations=0,same_name_entries=matches,package_bytes=package.stat().st_size)
print(json.dumps(status,ensure_ascii=False,indent=2))
