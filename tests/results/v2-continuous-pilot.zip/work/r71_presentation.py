"""Exposed R70 encoding repair + pre-frozen new attachment variation, no model."""
import io,json,sys,zipfile
from pathlib import Path
from v2_continuous_pilot import OUT,REPO

sys.path.insert(0,str(REPO/'pilot'))
from build_trial import recipient_archive

def extract(data,dest):
 dest.mkdir(parents=True)
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  for n in z.namelist():
   if not n.endswith('/'):
    target=dest/n;assert target.resolve().is_relative_to(dest.resolve())
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(n))

old=OUT.parent/'business-pilot-r70/runs/r70/handoff/V2/workspace/outputs/client.zip'
original=old.read_bytes()
with zipfile.ZipFile(OUT/'intent-compiler-local-pilot-r71.zip') as z:fixed=z.read('sample/outputs/client.zip')
assert fixed==recipient_archive(original) and old.read_bytes()==original
extract(fixed,OUT/'ux/photo-fixed')
fixture=json.loads((OUT/'transfer-frozen.json').read_text(encoding='utf-8-sig'))
out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,t in fixture['recipientFiles'].items():z.writestr(n,t.encode('utf-8'))
transfer_before=out.getvalue();transfer_after=recipient_archive(transfer_before)
(OUT/'transfer-before.zip').write_bytes(transfer_before);(OUT/'transfer-after.zip').write_bytes(transfer_after)
extract(transfer_before,OUT/'ux/transfer-before');extract(transfer_after,OUT/'ux/transfer-after')
results={}
for label,before,after in [('exposed-r70',original,fixed),('held-out-attachment',transfer_before,transfer_after)]:
 with zipfile.ZipFile(io.BytesIO(before)) as a,zipfile.ZipFile(io.BytesIO(after)) as b:
  assert a.namelist()==b.namelist()
  changed=[]
  for n in a.namelist():
   first=a.read(n);last=b.read(n)
   if n.lower().endswith('.txt'):
    assert last==b'\xef\xbb\xbf'+first.decode('utf-8-sig').encode('utf-8')
    changed.append(n)
   else:assert first==last
  results[label]={'sameNames':True,'decodedTextPreserved':True,'nonTextBytesPreserved':True,'changedEncodingOnly':changed,'files':b.namelist()}
 with zipfile.ZipFile(io.BytesIO(recipient_archive(after))) as repeated,zipfile.ZipFile(io.BytesIO(after)) as b:
  assert all(repeated.read(n)==b.read(n) for n in b.namelist())
assert all(n not in fixture['outsideRecipient'] for n in fixture['recipientFiles'])
(OUT/'presentation-check.json').write_text(json.dumps({'checks':results,'sourceArchiveUntouched':True,
 'browser':'Pending actual link opening; byte checks alone are not recipient UX acceptance',
 'limits':'Presentation packaging transfer only, not an unseen Skill/model behavior test or real publisher adoption'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
