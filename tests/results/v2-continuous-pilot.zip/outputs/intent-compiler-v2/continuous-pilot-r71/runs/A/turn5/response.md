已使用指定脚本打包，两次均成功，复核通过：

- [客户包](ready/client.zip)
- [印厂 B 包](ready/printer-B.zip)
- [内部交接](internal/同事交接_v4.md)
- [内部校验记录](internal/ready_validation.json)

收件包未混入讨论预览、旧版、原始资料或内部记录；印厂包不含客户收费和内部成本。原始输入与历史保留，未外发或下单。