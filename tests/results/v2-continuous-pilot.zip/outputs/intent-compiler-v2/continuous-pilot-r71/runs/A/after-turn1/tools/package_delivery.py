"""Synthetic local packer: first call fails before writing; later calls create one ZIP."""
import json,sys,zipfile
from pathlib import Path
p=Path(__file__).resolve().parent
log=p/'attempts.jsonl'
row={'argv':sys.argv[1:]}
if not log.exists():
 row.update(status='simulated_transient_failure',exit_code=75)
 log.write_text(json.dumps(row)+'\n',encoding='utf-8')
 print('SIMULATED transient packaging error; no output written. Retry the same command.',file=sys.stderr)
 sys.exit(75)
if len(sys.argv)!=3:raise SystemExit('Usage: python tools/package_delivery.py SOURCE_DIRECTORY TARGET_ZIP')
src=Path(sys.argv[1]);dst=Path(sys.argv[2])
if not src.is_dir() or dst.resolve().is_relative_to(src.resolve()):raise SystemExit('Source must exist and target must be outside it')
files=sorted(f for f in src.rglob('*') if f.is_file())
if not files:raise SystemExit('Empty delivery is not accepted')
dst.parent.mkdir(parents=True,exist_ok=True)
tmp=dst.with_suffix('.tmp')
with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.relative_to(src).as_posix())
tmp.replace(dst)
row.update(status='success',exit_code=0,target=str(dst),files=[f.relative_to(src).as_posix() for f in files])
with log.open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
print('Packaged',dst)
