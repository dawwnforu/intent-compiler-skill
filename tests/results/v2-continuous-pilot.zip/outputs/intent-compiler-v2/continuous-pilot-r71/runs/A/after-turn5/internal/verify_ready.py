from pathlib import Path
import hashlib, json, zipfile

root = Path(__file__).resolve().parent.parent
report = {'packages': {}, 'external_actions': 'none', 'print_ready': False}
for archive, folder, names in [
    ('client.zip', 'client', {'客户确认单.md', '客户离线确认页.html'}),
    ('printer-B.zip', 'printer_B', {'印厂B询价规格.md'})
]:
    target = root / 'ready' / archive
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist()) == len(names) and set(z.namelist()) == names
        assert z.testzip() is None
        for name in names:
            data = z.read(name)
            assert data == (root / 'internal/delivery_stage' / folder / name).read_bytes()
            text = data.decode('utf-8')
            for banned in ['PRIVATE_COST', 'INTERNAL_PHONE', 'OTHER_CLIENT', '13911112222', '360', '500', '优惠券', '90×50', 'sources/', 'print-archive', '印厂 A', '印厂A', '草稿', '内容层级预览.html']:
                assert banned not in text, (archive, name, banned)
            assert '300' in text and 'A5' in text
            if folder == 'printer_B':
                for banned in ['800', '200', '600', '排版费', '定金', '余款', '内部成本']:
                    assert banned not in text
                assert '印厂 B' in text
            else:
                for required in ['800', '200', '600', '尚未支付', '定稿后支付', '不代付印刷费']:
                    assert required in text
            if name.endswith('.html'):
                for banned in ['http:', 'https:', 'fetch(', 'XMLHttpRequest', 'src=', '<link', '<form', '<iframe']:
                    assert banned not in text
    report['packages'][archive] = {'members': sorted(names), 'zip_integrity': 'passed', 'source_byte_match': True, 'recipient_isolation': 'passed', 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
assert set(p.name for p in (root / 'ready').iterdir()) == {'client.zip', 'printer-B.zip'}
prior = json.loads((root / 'outputs/validation_v4.json').read_text(encoding='utf-8'))
assert prior['input_sha256'] == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'inputs').iterdir() if p.is_file()}
assert (root / 'outputs/history/v3_superseded/印厂询价准备包.zip').exists()
rows = [json.loads(row) for row in (root / 'tools/attempts.jsonl').read_text(encoding='utf-8').splitlines()]
for archive, folder in [('client.zip', 'client'), ('printer-B.zip', 'printer_B')]:
    matching = [row for row in rows if row.get('argv') == [f'internal/delivery_stage/{folder}', f'ready/{archive}']]
    assert matching and matching[-1]['status'] == 'success' and matching[-1]['exit_code'] == 0
report.update(original_inputs_unchanged=True, history_retained=True, ready_contains_only_two_recipient_packages=True, packer_results='both succeeded on this turn; no retry needed', html_check='offline dependency/structure checked; browser rendering not checked')
(root / 'internal/ready_validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('Verified both ready ZIPs: exact allowlists, integrity, byte equality, current scope, privacy, offline dependencies, input hashes and packer success records.')
