本地模拟打包工具，无联网；输入为仅含该收件人文件的独立目录。命令：python tools/package_delivery.py SOURCE_DIRECTORY TARGET_ZIP
失败会给出错误。attempts.jsonl 是内部操作记录，不放入收件包。
