from pathlib import Path
raise SystemExit('Superseded by v3. Do not regenerate obsolete v2 materials; current files are in client/ and printer/.')

out = Path(__file__).resolve().parent
def put(name, text):
    (out / name).write_text(text.strip() + '\n', encoding='utf-8')

put('client/客户确认单.md', '''
# 松河展会宣传单｜客户确认单 v2

更新依据：本会话项目负责人补充确认。未外发，非印刷定稿。

## 已确认

- 用途：展会派发；成品 A5（148×210mm），双面，300 张。
- 排版费共 800 元；定金 200 元尚未支付；余款 600 元于定稿后支付。尚无到账确认，不能标记已收款。
- 设计师仅负责设计与询价，不代付印刷费。印刷费用另行报价与支付，不并入上述排版费。

## 仍需客户确认

- 最终文案：当前仅有“松河手作展会活动：欢迎到场了解新品。”请确认或修改，并补产品介绍、活动日期地点及所需联系渠道。
- 提供高清 LOGO 和经授权的产品图片。展位号未定，不编造；若定稿前仍未知，请确认是否删去。
- 纸张种类、克重、色彩及表面工艺均待确认，不默认选用铜版纸、覆膜或任何报价选项。
- 版面方向及正反面内容分配仍待确认；预览暂按竖向组织，非已确认设计。
- 补收货城市/邮编及最晚签收时间。希望 2026-11-12 前收到，尚未经印厂确认，非交期承诺。

## 审阅记录（待填写，不自动视为同意）

文案版本/修改意见：____；素材版本：____；纸张/克重：____；色彩/工艺：____。

版面方向及正反面意见：____；收货信息：____；确认人/日期：____。

最终版面、印厂报价及交期须分别确认。本确认单不授权付款、下单或开印。
''')

put('printer/印厂询价准备单.md', '''
# 印厂 A｜松河宣传单询价规格 v2

本地待发送草稿，仅供询价；不是订单或开印许可。

| 项目 | 规格或状态 |
|---|---|
| 成品 | A5，148×210mm |
| 印刷面数 | 双面 |
| 成品数量 | 300 张 |
| 版面方向 | 待确认 |
| 色彩 | 待客户确认，请说明可选印刷方式及价格差异 |
| 纸张、克重 | 待客户确认，请提供适合展会派发的可选纸张、克重及对应报价，不默认选纸 |
| 表面及后道工艺 | 待客户确认；基础报价和可选工艺分别列明，不默认覆膜 |
| 文件状态 | 文案及素材待确认，暂无可生产文件 |
| 收货 | 城市/邮编待补；目标 2026-11-12 前签收，需核实可行性 |

请按 300 张分别列出各纸张/工艺选项的单价、总价、税费、运费、打样费及其他必要费用，注明含税情况、报价有效期、起印量及数量允差；若无法承接 300 张请明确说明，勿自行改量。

请列打样和生产所需时间、运输时效、最晚定稿节点及付款条件。地址未提供前请注明到货时效的估算依据；不能以出厂日代替签收日。

请提供 PDF 标准、ICC/色彩要求、黑色设置、图片分辨率、字体处理、出血、安全边距及正反面翻转要求。四边 3mm 出血、重要内容距裁切至少 5mm 仅作待核对建议，以双方确认的印前规范为准。

纸张、工艺、文件及交期未确认前不得视为可生产。本材料只用于规格询价。
''')

put('client/客户离线确认页.html', '''
<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>松河宣传单｜客户确认页</title>
<style>body{margin:0;background:#eeeae2;color:#253b32;font:16px/1.8 'Microsoft YaHei',sans-serif}main{max-width:850px;margin:24px auto;padding:32px;background:#fffdf6}h1{line-height:1.3}h2{margin-top:28px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #b9c5ba;padding:10px;text-align:left}.note{padding:14px;background:#f2e8d7}label{display:block;margin:14px 0}textarea{box-sizing:border-box;width:100%;min-height:80px;font:inherit}button{padding:10px 18px;font:inherit}@media print{body,main{background:white;margin:0}button{display:none}main{padding:12px}textarea{border:1px solid #aaa}}@media(max-width:600px){main{margin:0;padding:20px}}</style></head>
<body><main><p>客户确认页 v2 · 本地离线文件</p><h1>松河展会宣传单</h1><p class="note">用于核对项目约定与待定事项，非印刷稿。本页不联网、不提交信息；填写内容刷新或关闭后可能丢失，请打印或另存 PDF 留存。打印不代表已向设计师发送或完成确认。</p>
<h2>已确认的项目约定</h2><table><tr><th>项目</th><th>当前约定</th></tr><tr><td>规格及数量</td><td>A5（148×210mm），双面，300 张</td></tr><tr><td>排版费</td><td>共 800 元</td></tr><tr><td>定金</td><td>200 元，尚未支付</td></tr><tr><td>余款</td><td>600 元，定稿后支付</td></tr><tr><td>设计师职责</td><td>设计与询价；不代付印刷费。印刷费用另行报价与支付。</td></tr></table>
<h2>内容方向，待审定</h2><blockquote>松河手作展会活动：欢迎到场了解新品。</blockquote><p>这句话来自已有资料，尚未成为最终文案。正面暂建议突出品牌与邀请，背面暂建议放产品信息及到场指引；版面方向和内容分配均待确认。</p><p>可另打开同包内“内容层级预览.html”查看信息顺序；其尺寸、色彩和页面分配均非最终设计。</p>
<h2>需要您补充或决定</h2><p>请提供高清 LOGO、产品介绍及有权使用的图片；补活动日期地点、展位号及所需联系渠道。展位号未定时请明确是否在本版删去，勿以占位文字进入印刷。</p><p>纸张种类、克重、印刷色彩和表面工艺仍待您确认，未默认选择任何纸张或覆膜方案。</p><p>期望 2026-11-12 前签收，尚未经印厂核实。请补收货城市/邮编及最晚签收时间；最终交期以印厂确认结果为准。</p>
<h2>审阅意见（手动填写）</h2><label>最终文案版本、修改意见及素材版本<textarea aria-label="文案与素材意见" placeholder="待填写；空白不表示同意"></textarea></label><label>纸张、克重、色彩与工艺选择<textarea aria-label="纸张与工艺" placeholder="待报价比较后确认；不预选"></textarea></label><label>版面方向、正反面内容及展位号处理<textarea aria-label="版面意见"></textarea></label><label>收货城市/邮编及最晚签收时间<textarea aria-label="收货要求"></textarea></label><label>确认人、日期及其他意见<textarea aria-label="确认记录"></textarea></label>
<button type="button" onclick="window.print()">打印或另存 PDF 留存</button><p class="note">待定项须另行明确确认，空白及打印均不构成确认。最终版面、报价及交期需分别核对，本页不授权付款、下单或开印。</p></main></body></html>
''')

p = out / 'client/内容层级预览.html'
s = p.read_text(encoding='utf-8')
s = s.replace('尺寸及单双面待确认。', '已确认 A5 双面、300 张；此处仅展示内容模块。')
s = s.replace('A4 单面：可集中为一页；A5 双面：可将新品信息及到场指引放在背面。确认规格和素材后另作实际排版。', 'A5 双面、300 张已确认。暂建议新品信息及到场指引放在背面，内容分配及版面方向仍待确认。素材与文案确认后另作实际排版。')
p.write_text(s, encoding='utf-8')

put('内部工作说明.md', '''
# 内部执行表 v2｜仅自己及接手同事

本会话补充确认优先于原草案：A5 双面、300 张。已排除 A4 单面及原建议询价档位。原始 inputs 保留，内部成本与私人资料仍仅在原始内部资料中，不复制到交付包。

| 执行事项 | 当前状态 | 下一步及完成条件 |
|---|---|---|
| 成品规格 | A5 148×210mm、双面、300 张已确认 | 版面方向和正反面内容分配待客户确认 |
| 排版费 | 总额 800 元 | 不与印刷费合并；不向印厂披露 |
| 定金 | 200 元尚未付；当前无已收款记录 | 核实到账后登记实收及日期，不虚记收入 |
| 余款 | 600 元，定稿后支付 | 定稿确认后跟进；当前未到付款节点，未记录已收 |
| 职责 | 仅设计与询价，不代付印刷费 | 印刷费用另行报价和支付；具体付款主体及生产安排需另行落实，不作承诺 |
| 最终文案 | 未确认 | 客户审定邀请句，补产品及活动资料 |
| 素材及展位号 | 缺高清 LOGO；展位号待定 | 索取可用素材；展位未定时由客户决定删除或补入 |
| 纸张、克重、色彩、工艺 | 未确认 | 收集印厂选项及差价，再由客户选择，不代为拍板 |
| 交期 | 目标 2026-11-12 前收到，未获印厂承诺 | 补城市/邮编及最晚签收要求，核实打样、生产和运输周期 |
| 询价 | 仅完成印厂 A 本地规格材料 | 当前不外发；日后明确授权才外联。只提供 printer 包，不附客户包或内部文件 |
| 印刷文件 | 尚无可生产 PDF | 完成内容、素材和纸张确认，取得印厂规范后排版；检查尺寸、出血、字体、图片、色彩、正反面及待补标记 |
| 定稿与生产 | 未定稿，未下单 | 留存客户明确校样确认；付款及生产授权另行落实，不因规格确认而自动开印 |

## 收件边界

- client：客户离线确认页、客户确认单和内容层级预览；含客户排版费及付款安排，不含内部成本、私人电话或其他客户资料。
- printer：只含印厂 A 的印刷规格询价材料；不含客户收费、收款状态、内部成本和联系人隐私。
- 两个 ZIP 分别只从对应独立目录生成。整个 outputs、inputs、执行表、验证脚本及 tools/attempts.jsonl 均不得交给收件人。

## 验证与限制

validation.json 记录包成员、字节一致性、ZIP 完整性及敏感信息扫描。离线页无外部依赖、无网络提交；打印仅供留存，不等于远程确认。完成 HTML 结构检查，尚未作浏览器视觉验收。未外发、上传、付款、下单或安装依赖。
''')
print('Updated client, printer and internal materials.')
