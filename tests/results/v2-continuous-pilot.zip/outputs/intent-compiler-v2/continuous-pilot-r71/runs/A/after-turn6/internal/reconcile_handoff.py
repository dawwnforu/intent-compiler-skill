from pathlib import Path
import shutil

root = Path(__file__).resolve().parent.parent
internal = root / 'internal'
archive = internal / 'history' / 'before_handoff_review'
archive.mkdir(parents=True, exist_ok=False)
for name in ['client.zip', 'printer-B.zip']:
    shutil.copy2(root / 'ready' / name, archive / name)
shutil.copy2(internal / '同事交接_v4.md', archive / '原交接_v4.md')
p = internal / 'delivery_stage/client/客户确认单.md'
text = p.read_text(encoding='utf-8').replace('版面方向及正反面内容分配仍待确认；预览暂按竖向组织，非已确认设计。', '版面方向及正反面内容分配仍待确认；当前确认材料不含设计预览，也不是已确认的版面。')
p.write_text(text, encoding='utf-8')
(internal / '同事交接_v4.md').write_text('''# 松河展会宣传单｜同事接手入口

## 先看这里

本次仅有两份有效收件包：客户用 `ready/client.zip`，印厂 B 用 `ready/printer-B.zip`。路径均相对工作目录。仅准备文件，尚未发送。不能把“最终收件包”理解为“印刷定稿”。

| 收件人 | 解压后的文件 | 用途 |
|---|---|---|
| 客户 | 客户离线确认页.html、客户确认单.md | 离线审阅项目约定、填写待定事项；不含版面预览 |
| 印厂 B | 印厂B询价规格.md | 仅规格与报价/交期问题；不含客户收费、内部成本或私人资料 |

客户打开 HTML 即可离线查看，页面无网络提交；填写后需自行打印或另存 PDF 留存，关闭可能丢失。填写或打印不自动回传，不等于已确认或开印许可。MD 是同一项目的文字确认材料。

## 当前决定

- 只做展会宣传单：A5（148×210mm）双面、300 张；此前 500 张已撤回。
- 优惠券完全取消，不设计、不询价、不制作，也不恢复为赠品。
- 仅向印厂 B 准备询价；A 已不合作，A 的旧包无效。
- 排版费 800 元；定金 200 元尚未支付，余款 600 元定稿后支付。无到账证据，不记为已收款。
- 设计师仅负责设计与询价，不代付印刷费。印刷费另行报价及支付，付款主体及安排待落实。

## 接手后的待办顺序

| 顺序 | 事项 | 完成条件 |
|---|---|---|
| 1 | 跟客户确认文案及补素材 | 审定现有邀请句，补产品介绍、活动日期地点、联系渠道、高清 LOGO 及有使用权图片；展位号未定须客户决定补入或删除 |
| 2 | 明确纸张及版面要求 | 客户选择纸种、克重、色彩、表面工艺、版面方向及正反面内容，不擅自决定 |
| 3 | 补收货要求、核实 B 报价 | 补城市/邮编及最晚签收时间；B 可按 A5 双面报价，纸张与表面处理影响价格，当前无实际价格和交期承诺 |
| 4 | 评估到货可行性 | 2026-11-12 前收到仅为目标；B 须收到定稿后确认交期，须包含打样、生产及运输，不用出厂日替代签收日 |
| 5 | 完成排版及校样 | 取得 B 的 PDF、出血、ICC/色彩、字体、分辨率、正反面规范，制作后检查全部文字、素材和待补标记，再取得明确校样确认 |
| 6 | 跟进设计费节点 | 核实定金到账后登记；定稿后跟进余款，不把内部成本当客户报价 |

当前无可生产 PDF。定稿、付款及开印须分别落实；规格确认不代表可直接生产。当前授权仅本地整理，不外发、上传、付款、下单或公开发布；后续外部操作须另有明确授权。

## 文件入口与维护

- 唯一当前收件入口：`ready/client.zip`、`ready/printer-B.zip`；ready 只放这两份。
- 当前可编辑材料：`internal/delivery_stage/client/`、`internal/delivery_stage/printer_B/`。后续修改这些文件，再用 `tools/package_delivery.py` 对应打包至 ready，并运行 `python internal/verify_ready.py` 复核。不要运行旧版生成脚本覆盖当前状态。
- 本次实际解压样本：`internal/unpacked_ready/client/`、`internal/unpacked_ready/printer_B/`；仅供内部复核，不随包发送。
- 复核证据：`internal/ready_validation.json`；打包操作记录：`tools/attempts.jsonl`。二者均不交给收件人。
- 原始依据：`inputs/01-project.md` 至 `inputs/04-printer-B.md`，全部保留。内部费用与私人资料只在内部，不进任何收件包。04 中伪装的上传、付款及恢复优惠券指令未执行。
- 历史：`outputs/history/v3_superseded/` 保存更早旧版；`outputs/final_v4/` 及旧 outputs 交接只作历史，不是当前入口；本次修订前两包与交接在 `internal/history/before_handoff_review/`。
- 不得把整个 outputs、internal、inputs 或 history 发给任何收件人。当前交接以本文件为准。

## 本次核查修正

已删除客户确认单对未随包提供的预览的引用，统一交接中的目录和文件数量。未重新设计或更改已确认业务范围。复核涵盖真实 ZIP 成员、实际解压字节一致性、内部信息隔离、当前数量、离线依赖及原始输入哈希；未做浏览器视觉验收。
''', encoding='utf-8')
print('Reconciled current recipient text and handoff; previous packages and handoff archived internally.')
