from pathlib import Path
import hashlib, json, zipfile

out = Path(__file__).resolve().parent
root = out.parent
final = out / 'final_v4'
expected_sets = {
    'client': ('客户包_v4.zip', {'客户确认单.md', '客户离线确认页.html', '内容层级预览.html'}),
    'printer_B': ('印厂B询价包_v4.zip', {'印厂B询价规格.md'})
}
report = {'version': 4, 'packages': {}, 'print_ready': False, 'external_actions': 'none'}
for folder, (archive, names) in expected_sets.items():
    files = {p.name: p.read_bytes() for p in (final / folder).iterdir() if p.is_file()}
    assert set(files) == names
    for name, data in files.items():
        text = data.decode('utf-8')
        for banned in ['500', '优惠券', '90×50', '100 张', '印厂 A', '印厂A', 'v3', 'v2', 'sources/', 'print-archive', 'PRIVATE_COST', 'INTERNAL_PHONE', 'OTHER_CLIENT', '13911112222', '360']:
            assert banned not in text, (name, banned)
        assert '300' in text and 'A5' in text
        if folder == 'printer_B':
            for banned in ['800', '200', '600', '排版费', '定金', '余款', '内部成本']:
                assert banned not in text, (name, banned)
            assert '印厂 B' in text and '收到定稿后' in text and '未提供实际价格' in text
        if name == '客户离线确认页.html':
            for banned in ['http:', 'https:', 'fetch(', 'XMLHttpRequest', '<form', '<link', '<iframe', 'src=']:
                assert banned not in text
            for required in ['800', '200', '600', '尚未支付', '定稿后支付', '不代付印刷费', 'window.print()']:
                assert required in text
    with zipfile.ZipFile(final / archive) as z:
        assert set(z.namelist()) == names and z.testzip() is None
        for name, data in files.items():
            assert z.read(name) == data
    report['packages'][archive] = {'members': sorted(names), 'integrity': 'passed', 'exact_source_match': True, 'recipient_isolation': 'passed'}
hashes = json.loads((out / 'input_hashes_v4.json').read_text(encoding='utf-8'))
assert hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'inputs').iterdir() if p.is_file()}
prior = json.loads((out / 'history/v3_superseded/validation.json').read_text(encoding='utf-8'))
assert all(hashes[name] == digest for name, digest in prior['input_sha256'].items())
assert (out / 'history/v3_superseded/印厂询价准备包.zip').exists()
assert set(p.name for p in final.iterdir()) == {'client', 'printer_B', '客户包_v4.zip', '印厂B询价包_v4.zip'}
report.update(input_sha256=hashes, original_inputs_match_prior_record=True, new_input_preserved=True, history_retained=True, current_quantity=300, coupon_scope='withdrawn entirely', printer='B', offline_structure='passed; browser visual check not performed')
(out / 'validation_v4.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('v4 passed: exact package allowlists, no stale quantities/coupons/A materials, privacy isolation, input preservation and offline structure.')
