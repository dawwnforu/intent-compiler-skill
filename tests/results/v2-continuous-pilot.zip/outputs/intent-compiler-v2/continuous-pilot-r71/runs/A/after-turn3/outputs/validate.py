from pathlib import Path
import hashlib, json, zipfile

root = Path(__file__).resolve().parent.parent
out = root / 'outputs'
inputs_before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'inputs').iterdir() if p.is_file()}
previous = json.loads((out / 'validation.json').read_text(encoding='utf-8'))
assert inputs_before == previous['input_sha256'], 'Original input changed since previous verification'
checks = {}
for folder, archive in [('client', '客户确认包.zip'), ('printer', '印厂询价准备包.zip')]:
    expected = {p.relative_to(out / folder).as_posix(): p.read_bytes() for p in (out / folder).rglob('*') if p.is_file()}
    with zipfile.ZipFile(out / archive) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == set(expected)
        for name, data in expected.items():
            assert z.read(name) == data
            for marker in [b'PRIVATE_COST', b'INTERNAL_PHONE', b'OTHER_CLIENT', b'13911112222', b'360', b'attempts.jsonl']:
                assert marker not in data, (archive, name, marker)
            if folder == 'printer':
                for marker in ['800', '200', '600', '360', '排版费', '定金', '余款', '内部成本', 'PRIVATE_COST', 'INTERNAL_PHONE', 'OTHER_CLIENT']:
                    assert marker not in data.decode('utf-8'), (archive, name, marker)
    checks[archive] = {'members': sorted(expected), 'integrity': 'passed', 'matches_source': True, 'internal_marker_scan': 'passed'}
html = (out / 'client' / '内容层级预览.html').read_text(encoding='utf-8')
assert '<meta charset="utf-8">' in html and '</html>' in html and '非印刷稿' in html
offline = (out / 'client' / '客户离线确认页.html').read_text(encoding='utf-8')
for forbidden in ['http:', 'https:', 'fetch(', 'XMLHttpRequest', '<form', '<link', '<iframe', 'src=', 'localStorage']:
    assert forbidden not in offline
for required in ['800', '200', '600', '500', '100', '90×50', '未批准制作', '尚未支付', '定稿后支付', '不代付印刷费', '待您确认', 'window.print()']:
    assert required in offline
for folder in ['client', 'printer']:
    for p in (out / folder).rglob('*'):
        if p.is_file():
            for stale in ['A4', '300', 'v2', '500 / 1000 / 2000', '尺寸及单双面待确认', '两种方案']:
                assert stale not in p.read_text(encoding='utf-8'), (p.name, stale)
            for required in ['500', '100', '90×50', '未批准制作']:
                assert required in p.read_text(encoding='utf-8'), (p.name, required)
inputs_after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'inputs').iterdir() if p.is_file()}
assert inputs_before == inputs_after
report = {'packages': checks, 'input_sha256': inputs_after, 'inputs_unchanged_during_validation': True, 'input_note': 'Hashes recorded after creation of drafts; no original input was edited by this workflow.', 'html_structure_check': 'passed; browser rendering not checked', 'print_ready': False, 'external_actions': 'none', 'packaging_note': 'First customer-package attempt failed with the supplied simulated transient error; identical command retried successfully. tools/attempts.jsonl stays internal.'}
report.update(version=3, inputs_match_previous_record=True, offline_page_dependency_check='passed', printer_client_financial_data_scan='passed', obsolete_specs_scan='passed', confirmed_flyer_quantity=500, optional_coupon={'quantity':100, 'size_mm':'90x50', 'production_approved':False})
(out / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('Validation passed: package membership, byte equality, ZIP integrity, internal markers and HTML structure.')
