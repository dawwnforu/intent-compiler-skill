from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
internal = root / 'internal'
stage = internal / 'delivery_stage'
for folder in ['client', 'printer_B']:
    (stage / folder).mkdir(parents=True, exist_ok=True)
for name in ['客户确认单.md', '客户离线确认页.html']:
    text = (root / 'outputs/final_v4/client' / name).read_text(encoding='utf-8')
    text = text.replace('<p>可另打开同包内“内容层级预览.html”查看信息顺序；其尺寸、色彩和页面分配均非最终设计。</p>', '')
    (stage / 'client' / name).write_text(text, encoding='utf-8')
text = (root / 'outputs/final_v4/printer_B/印厂B询价规格.md').read_text(encoding='utf-8')
text = text.replace('本地待发送草稿，仅供询价；不是订单或开印许可。', '仅供询价；不是订单或开印许可。')
(stage / 'printer_B/印厂B询价规格.md').write_text(text, encoding='utf-8')
shutil.copy2(root / 'outputs/内部交接_v4.md', internal / '同事交接_v4.md')
with (internal / '同事交接_v4.md').open('a', encoding='utf-8') as f:
    f.write('\n## 本次交付路径更新\n\n当前收件包以 ready/client.zip 与 ready/printer-B.zip 为准，替代此前 outputs 下的包。客户包仅含离线确认页和确认单，已排除内容层级讨论预览，移除对该预览的链接；印厂 B 包仅含当前询价规格。内部暂存、历史、原始资料及操作记录不入包。打包与复核结果见 internal/ready_validation.json。所有非印刷定稿提示保留，不能将确认材料视为生产文件。\n')
print('Prepared explicit recipient allowlists in internal/delivery_stage; handoff is internal.')
