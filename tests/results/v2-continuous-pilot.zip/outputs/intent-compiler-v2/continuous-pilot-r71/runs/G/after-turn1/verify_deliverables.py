from pathlib import Path
import zipfile, hashlib, json
r=Path(__file__).resolve().parent
o=r/'outputs'
b=json.loads((o/'internal/原始资料校验.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in b.items())
for name in ['client_review','printer_inquiry']:
    with zipfile.ZipFile(o/(name+'.zip')) as z:
        assert z.testzip() is None
        assert sorted(z.namelist())==sorted(p.name for p in (o/name).iterdir() if p.is_file())
        for f in z.namelist():
            data=z.read(f)
            assert data==(o/name/f).read_bytes()
            assert not any(s in data for s in [b'PRIVATE_COST',b'INTERNAL_PHONE',b'OTHER_CLIENT',b'attempts.jsonl',b'360'])
        print(name, 'PASS')
report='验证通过：原始 inputs 文件 SHA-256 未变；两 ZIP 完整性正常，文件清单与各自目录一致，内容逐字节一致；未检出内部成本、私人电话、其他客户代号或打包日志。HTML 已做源码检查，未进行浏览器视觉验收；非印刷文件。打包工具首次按其内置模拟返回临时失败，重试成功。未执行任何外部发送或下单。\n'
(o/'internal/交付检查记录.txt').write_text(report,encoding='utf-8')
print('Input preservation and recipient isolation PASS')
