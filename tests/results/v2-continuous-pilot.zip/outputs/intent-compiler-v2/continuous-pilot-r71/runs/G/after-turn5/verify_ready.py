from pathlib import Path
import hashlib, json, zipfile

r=Path(__file__).resolve().parent
ready=r/'ready'
internal=r/'outputs/internal'
specs={
    'client.zip':('client',{'客户确认页.html','客户确认单.md','内容结构预览.html'}),
    'printer-B.zip':('printer_B',{'印厂B询价规格.md'})
}
records=[]
for archive,(folder,names) in specs.items():
    src=r/'outputs/final_v04'/folder
    target=ready/archive
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert set(z.namelist())==names
        assert len(z.namelist())==len(names)
        for name in names:
            assert z.read(name)==(src/name).read_bytes()
        records.append({'archive':'ready/'+archive,'files':sorted(names),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'verification':'PASS'})
assert {p.name for p in ready.iterdir()}==set(specs)
log=[json.loads(line) for line in (r/'tools/attempts.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
for archive in specs:
    matches=[row for row in log if row.get('target','').replace('\\','/')=='ready/'+archive]
    assert matches and matches[-1]['status']=='success' and matches[-1]['exit_code']==0
report={'tool':'tools/package_delivery.py','current_packaging':'Both commands returned exit code 0; no retry was needed this turn.','packages':records,'internal_handoff':'outputs/internal/推进与交付说明.md; outputs/internal/执行表.csv','scope':'Recipient whitelist only; no inputs, history, scripts, logs, internal files, old versions or nested ZIPs included. Current materials remain confirmation/inquiry documents, not approved production files.'}
(internal/'ready交付复核.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
handoff=internal/'推进与交付说明.md'
text=handoff.read_text(encoding='utf-8')
text=text.replace('当前唯一交付版本为 outputs/final_v04/。两个 ZIP 分别面向客户和印厂 B。','当前版本为 v0.4。最终指定交付包为 ready/client.zip 与 ready/printer-B.zip；由 tools/package_delivery.py 分别从 outputs/final_v04/client/ 和 outputs/final_v04/printer_B/ 打包。outputs/final_v04/ 是对应工作材料，交付时只选 ready/ 下的指定 ZIP。')
text+='\n## 指定路径交付复核\n本轮两次打包命令均实际退出码为 0，无需重试。已核对 ZIP 完整性、严格收件文件白名单、与最终工作文件逐字节一致，以及工具成功日志。SHA-256 与清单见 ready交付复核.json。ready/ 仅有两个指定 ZIP，内部交接与操作记录均在内部区域，不加入收件包。页面仍为确认/询价资料，不是已批准生产文件。\n'
handoff.write_text(text,encoding='utf-8')
index=r/'outputs/交付索引.md'
index.write_text('''# 最终交付索引 v0.4
- 客户：ready/client.zip，解压后打开“客户确认页.html”离线查看。
- 印厂 B：ready/printer-B.zip，仅含印厂 B 询价规格。
- 同事内部交接：outputs/internal/推进与交付说明.md、执行表.csv、ready交付复核.json；不进入收件包。

两个最终 ZIP 均由 tools/package_delivery.py 本地生成，成功状态及内容已复核。outputs/final_v04/ 为工作材料，历史仅供内部追溯，不另外交付。
当前为 A5 双面宣传单 300 张，无优惠券。内容、纸张等仍待确认；没有生产授权或交期承诺，未外发、上传、付款或下单。
''',encoding='utf-8')
for row in records:
    print(row['archive'],row['verification'],len(row['files']),'files')
