from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
out = root / 'outputs'
client = out / 'client_review'
printer = out / 'printer_inquiry'
internal = out / 'internal'
for folder in (client, printer, internal):
    folder.mkdir(parents=True, exist_ok=True)
baseline = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'inputs').iterdir() if p.is_file()}

def write(folder, name, content):
    (folder/name).write_text(content.strip()+'\n', encoding='utf-8')

write(client, '客户确认单.md', '''
# 松河展会宣传单｜客户确认稿 v0.1
状态：内容与版式结构讨论稿，尚未定稿，不可用于印刷。

## 已有信息
- 用途：展会现场派发。
- 当前提供的文案：“松河手作展会活动：欢迎到场了解新品。”该文字仍需最终确认。
- 期望在 2026-11-12 前收到成品；交货可行性待印厂核实。

## 请逐项确认或补齐
|事项|当前情况|确认/提供内容|
|---|---|---|
|尺寸与面数|原草案 A4 单面；后续口头 A5 双面，尚有冲突|明确选定一种：A4 单面 / A5 双面 / 另定|
|最终文字|目前只有一句活动介绍|确认原句，并提供需要增加的产品亮点、行动引导；无新增也请确认|
|品牌素材|缺高清 LOGO；未提供产品图|提供矢量 LOGO 或可印刷高清原文件；需要产品图时提供原图及使用权限确认|
|展会信息|展位号未定；无场馆、活动日期资料|确认是否刊登及对应准确信息；不刊登可明确省略|
|联系方式/二维码|未提供|确认是否需要；如需要请提供准确内容及可验证的链接/二维码|
|印量|未提供|提供总份数及是否需要阶梯报价|
|纸张/表面工艺|未决定|请印厂按适用常规纸张提出建议，并列明有无覆膜等工艺的差价|
|收货|仅有期望日期|提供收货城市/方式、可接受时间；详细地址在实际安排时再提供|
|预算|未提供|提供印刷预算范围（如有）|

## 如何查看预览
打开同目录“内容结构预览.html”。预览仅显示信息层级与两种备选结构；配色、字体和留白为设计建议，均待确认。没有使用虚构展位号、产品卖点或联系方式。

建议先确认尺寸、文字与素材，再核对最终样稿。定稿时还需确认纸张、工艺、印量、交付时间与印厂要求；本稿不代表已批准印刷。
''')

write(client, '内容结构预览.html', '''
<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>松河｜内容结构预览</title>
<style>body{font-family:'Microsoft YaHei',sans-serif;background:#eeeae2;color:#244437;margin:32px;line-height:1.7}main{max-width:960px;margin:auto}.notice{background:#fff5d6;padding:16px}section{margin:28px 0}.sheet{background:#fffdf7;border:1px solid #c6cabb;padding:36px;min-height:300px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:16px}.brand{font-size:15px;letter-spacing:4px}.hero{font-size:42px;line-height:1.3}small,.slot{color:#667269}.slot{border:1px dashed #a2ab9e;padding:16px;margin-top:24px}h2{font-size:22px}footer{margin:30px 0;font-size:13px}@media(max-width:650px){.pair{grid-template-columns:1fr}.hero{font-size:32px}}@media print{body{background:white;margin:12mm}.notice{border:1px solid}section{break-inside:avoid}}</style>
<main><h1>松河展会宣传单</h1><p class="notice">v0.1 · 内容结构讨论稿 · 非印刷文件<br>以下两种方案均未选定。屏幕比例、颜色、字体及留白仅供讨论，不代表成品尺寸或印刷效果。方框内文字是制作说明，不是正式宣传文案。</p>
<section><h2>备选 A｜A4 单面结构</h2><div class="sheet"><div class="brand">松河 · 手作</div><h3 class="hero">松河手作<br>展会活动</h3><p>欢迎到场了解新品。</p><div class="slot">LOGO 位置：待提供高清文件</div><div class="slot">如需产品介绍/产品图片：待提供并确认；无素材时调整留白与信息结构。</div><div class="slot">展位号及到场信息：待确认是否刊登和准确内容。</div></div></section>
<section><h2>备选 B｜A5 双面结构</h2><div class="pair"><div class="sheet"><small>正面建议</small><div class="brand">松河 · 手作</div><h3 class="hero">松河手作<br>展会活动</h3><p>欢迎到场了解新品。</p><div class="slot">LOGO 待提供</div></div><div class="sheet"><small>背面建议</small><h3>信息区（待补充）</h3><div class="slot">产品介绍、图片：待提供与确认。</div><div class="slot">展位信息、联系方式或二维码：按确认内容排版。未提供前不生成二维码。</div><p>当前文案较少，能否充实双面版需结合补充内容确认。</p></div></div></section>
<footer>原文为“松河手作展会活动：欢迎到场了解新品。”预览将其拆为标题与正文，需客户确认。定稿后按印厂模板另制含出血、色彩与字体检查的印刷 PDF。</footer></main></html>
''')

write(printer, '印刷询价草稿.md', '''
# 松河展会宣传单｜印刷询价草稿
状态：本地草稿，未发送；非订单、非生产授权，尚无可印刷文件。

用途为展会派发。期望在 2026-11-12 前收到成品，请评估是否可行，勿将此视为已承诺交期。

## 待补齐后询价的规格
|项目|内容|
|成品规格|待确认：A4（210 × 297 mm）单面，或 A5（148 × 210 mm）双面；两者为备选，不是两项订单|
|印量|待提供；请在确定数量后报价，如可提供阶梯价请列明数量档位|
|颜色|待确认；请列明报价采用的色数/彩色或黑白方式，勿自行视为已选定|
|纸张|待选，请建议适合展会派发的纸种与克重，并列出价格差异|
|表面工艺|待选，请分别说明不加表面工艺与推荐工艺的价格及时间差异|
|装订/折页|当前为宣传单需求，是否需要折页等额外加工待确认，不自动添加|
|送货|城市、方式待提供；运费与在途时间请单列|
|文件|尺寸、文案、LOGO 均未定稿，当前不可生产|

## 请印厂回复
1. 对应尺寸、面数、数量、纸张克重、色数、工艺的明细报价，注明税费、运费、打样费、有效期与损耗/交付数量规则。
2. 在收到合格印刷文件及必要确认后，打样、生产、发货、到货各需多久；为满足期望收货日，最晚何时定稿/确认样稿？不可满足时请说明可行日期。
3. 所需文件格式、出血、裁切安全距离、色彩空间/ICC 要求、图片有效分辨率、字体嵌入或转曲、正反面方向及模板。
4. 电子样/实物样的方式、费用、耗时，以及色差和裁切公差标准。

当前无法得出可靠总价或承诺交期。确认尺寸、数量、纸张工艺与收货城市后再形成可比报价；如先比较两种尺寸，请分项注明所有假设。任何生产都需另行确认最终文件与订单条件。
''')

write(internal, '推进与交付说明.md', '''
# 内部推进说明
本文件仅供设计师自己使用，不放入客户包或印厂包。

已完成：原资料检查、两种尺寸的内容结构预览、客户确认单、印厂询价草稿与分收件人本地打包。没有外发、上传或下单。

当前阻塞：尺寸需本会话用户确认；最终文案与高清 LOGO 缺失；展位号未定；印量、纸张、工艺、颜色及收货城市未确定。

建议顺序：
1. 向客户核对确认单，先解决尺寸和内容，再做完整排版。产品图/二维码如无需求可省略，但须确认。
2. 用明确规格取得可比报价；报价须记录纸张、工艺、税运、时效等假设。2026-11-12 前收货仅为期望，先确认最晚定稿日及运输余量。
3. 文案素材与版式获确认后，按印厂模板输出印刷 PDF。检查成品尺寸、出血、安全区、图片有效分辨率、色彩、字体、正反面方向，并核对二维码（如有）和全部文字。
4. 取得印厂文件检查结果及样稿，逐项确认价格、数量、材质、工艺、交期、收货信息和最终文件版本后才进入后续下单安排。本次不进行这些外部动作。

客户报价、收费与收款计划待用户另行决定；内部成本不等同客户售价。内部原始资料保持在 inputs/03-internal.md，不复制到收件包。

客户包只包含客户确认单与 HTML 结构预览；印厂包只包含询价草稿。两包均为未发送的本地预备包，不含内部资料和操作日志。
''')
write(out, '交付索引.md', '''
# 本地交付索引
- client_review/：客户确认单、可用浏览器打开的内容结构预览；对应 client_review.zip。
- printer_inquiry/：未发送的印刷询价草稿；对应 printer_inquiry.zip。
- internal/：内部推进说明、原件校验及交付检查记录，不用于外部交付。

全部为确认/询价准备材料。未生成可直接生产的印刷 PDF。两个尺寸方案均待选择；暂无最终文案、高清 LOGO、确定印量与材料工艺，不能宣称已具备生产条件。
''')
write(internal, '原始资料校验.json', json.dumps(baseline, ensure_ascii=False, indent=2))
assert baseline == {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'inputs').iterdir() if p.is_file()}
print('Created review materials; input SHA-256 unchanged.')
