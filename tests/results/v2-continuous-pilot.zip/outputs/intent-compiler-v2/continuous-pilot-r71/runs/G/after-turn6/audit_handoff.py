from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,zipfile,csv

r=Path(__file__).resolve().parent
internal=r/'outputs/internal'
audit=internal/'recipient_audit'
audit.mkdir(exist_ok=True)
specs={
 'client.zip':('client',{'客户确认页.html','客户确认单.md','内容结构预览.html'}),
 'printer-B.zip':('printer_B',{'印厂B询价规格.md'})
}
class Page(HTMLParser):
    def __init__(self,base):
        super().__init__(); self.base=base; self.visible=[]; self.hidden=False; self.links=[]
    def handle_starttag(self,tag,attrs):
        assert tag not in ('script','iframe','form')
        if tag=='style': self.hidden=True
        for key,value in attrs:
            if key in ('href','src'):
                assert ':' not in value and not value.startswith(('/', '\\'))
                target=(self.base/value).resolve()
                assert target.is_relative_to(self.base.resolve()) and target.is_file()
                self.links.append(value)
    def handle_endtag(self,tag):
        if tag=='style': self.hidden=False
    def handle_data(self,data):
        if not self.hidden: self.visible.append(data)

records=[]
for archive,(folder,expected) in specs.items():
    source=r/'ready'/archive
    dest=audit/folder
    dest.mkdir(exist_ok=True)
    with zipfile.ZipFile(source) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(expected) and set(z.namelist())==expected
        # Validate all entries before extracting; never trust archive paths.
        for name in z.namelist():
            assert (dest/name).resolve().is_relative_to(dest.resolve())
        z.extractall(dest)
    assert {p.name for p in dest.iterdir()}==expected
    checks=[]
    for name in sorted(expected):
        file=dest/name
        data=file.read_bytes()
        assert data==(r/'outputs/final_v04'/folder/name).read_bytes()
        text=data.decode('utf-8')
        assert all(s not in text for s in ['优惠券','500 张','印厂 A','印厂A','sources/','PRIVATE_COST','INTERNAL_PHONE','OTHER_CLIENT','print-archive','v0.3','v0.2'])
        links=[]
        if name.endswith('.html'):
            page=Page(dest);page.feed(text)
            text=' '.join(page.visible);links=page.links
        assert '300' in text and 'A5' in text
        if folder=='client' and name!='内容结构预览.html':
            assert all(s in text for s in ['800','200','600','尚未支付','定稿后支付','不代付'])
        if folder=='printer_B':
            assert all(s not in text for s in ['800','200','600','排版费','定金','余款','360'])
            assert '没有真实报价或交期承诺' in text
        checks.append({'file':name,'sha256':hashlib.sha256(data).hexdigest(),'local_links':links})
    records.append({'package':'ready/'+archive,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'extracted_files':checks,'result':'PASS'})

for name in ('原始资料校验.json','本次原始资料校验_v04.json'):
    baseline=json.loads((internal/name).read_text(encoding='utf-8'))
    assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==digest for p,digest in baseline.items())
assert {p.name for p in (r/'ready').iterdir()}==set(specs)
(internal/'收件人解压核查.json').write_text(json.dumps({'method':'Extracted actual ready ZIPs locally, checked visible HTML text and resolved links within each extracted recipient folder; no browser visual rendering performed.','packages':records,'inputs_unchanged':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Correct the stale working-directory entry without changing project decisions.
table=internal/'执行表.csv'
with table.open(encoding='utf-8-sig',newline='') as stream: rows=list(csv.reader(stream))
for row in rows[1:]:
    if row[0]=='供应商更换': row[2]='仅发送ready/printer-B.zip；旧A包仅内部保留'
    if row[0]=='版本交接': row[2]='仅使用ready/client.zip和ready/printer-B.zip并参考内部解压核查记录'
with table.open('w',encoding='utf-8-sig',newline='') as stream: csv.writer(stream).writerows(rows)
print('Actual recipient extraction audit PASS; packages unchanged; internal stale entry corrected.')
