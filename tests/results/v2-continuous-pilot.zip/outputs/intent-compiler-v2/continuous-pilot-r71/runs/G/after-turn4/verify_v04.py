from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,zipfile,csv

r=Path(__file__).resolve().parent
o=r/'outputs'
i=o/'internal'
f=o/'final_v04'
for name in ('原始资料校验.json','本次原始资料校验_v04.json'):
    data=json.loads((i/name).read_text(encoding='utf-8'))
    assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==digest for p,digest in data.items())
allow={
 '客户包_v04.zip':('client',{'客户确认页.html','客户确认单.md','内容结构预览.html'}),
 '印厂B包_v04.zip':('printer_B',{'印厂B询价规格.md'})
}
class Offline(HTMLParser):
    def handle_starttag(self,tag,attrs):
        assert tag not in ('script','iframe','form')
        for key,value in attrs:
            if key in ('href','src'):
                assert ':' not in value and not value.startswith('//')
                assert (f/'client'/value).is_file()

for archive,(folder,names) in allow.items():
    assert {p.name for p in (f/folder).iterdir()}==names
    with zipfile.ZipFile(f/archive) as z:
        assert z.testzip() is None and set(z.namelist())==names
        for name in z.namelist():
            raw=z.read(name)
            assert raw==(f/folder/name).read_bytes()
            text=raw.decode('utf-8')
            assert all(s not in text for s in ['优惠券','500','90 × 50','100 张','印厂 A','印厂A','v0.3','v0.2','PRIVATE_COST','INTERNAL_PHONE','OTHER_CLIENT','360','sources/','print-archive','下单并付款'])
            assert '300' in text and 'A5' in text
            if folder=='printer_B':
                assert '印厂 B' in text
                assert all(s not in text for s in ['800','200','600','定金','余款','排版费'])
                assert '没有真实报价或交期承诺' in text
            elif name.endswith('.html'):
                Offline().feed(text)
    print(archive, 'PASS')
page=(f/'client/客户确认页.html').read_text(encoding='utf-8')
assert all(s in page for s in ['800','200','600','尚未支付','定稿后支付','不代付'])
with (i/'执行表.csv').open(encoding='utf-8-sig',newline='') as stream:
    assert all(len(row)==5 for row in csv.reader(stream))
assert not (o/'client_review.zip').exists() and not (o/'printer_inquiry.zip').exists()
assert (i/'history_v03/printer_inquiry.zip').is_file()
assert (i/'history_v03/client_review/优惠券可选示意.html').is_file()
assert {p.name for p in f.iterdir()}=={'client','printer_B',*allow.keys()}
(i/'交付检查记录.txt').write_text('''v0.4 验证通过：
- 原三个输入与首次 SHA-256 一致；包含新印厂 B 说明的本次输入清单校验一致。
- 两个最终 ZIP 均通过完整性检查，文件清单严格符合收件人白名单，内容与对应最终目录逐字节一致。
- 最终材料统一 A5 双面 300 张，无优惠券、500 张、印厂 A、旧版本、原始资料、内部成本、私人信息或伪装授权内容。
- 印厂 B 包仅印刷询价规格，无客户收费与收款计划；无真实报价或交期承诺的状态明确。
- 客户费用与付款状态保留，所有 HTML 无外部资源、脚本、表单，本地链接存在；仅源码检查，未进行浏览器视觉验收。
- 旧目录和包仅存内部历史，当前根目录旧包已归档；最终目录仅两类收件材料和各自 ZIP，无历史嵌套。
- 执行表 CSV 列数正常。未外发、上传、付款或下单。无可生产印刷文件。
''',encoding='utf-8')
print('Inputs, recipient isolation, offline links, rollback and history PASS')
