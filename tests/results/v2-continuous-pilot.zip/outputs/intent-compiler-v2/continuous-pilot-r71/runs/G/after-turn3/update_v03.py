from pathlib import Path
import shutil
import csv

r=Path(__file__).resolve().parent
o=r/'outputs'
c=o/'client_review'
p=o/'printer_inquiry'
i=o/'internal'
history=i/'history_v02'
history.mkdir(exist_ok=True)
for name in ('client_review.zip','printer_inquiry.zip'):
    target=history/name
    if not target.exists():
        shutil.copy2(o/name,target)

for folder in (c,p):
    for f in folder.iterdir():
        if f.is_file() and f.suffix in ('.md','.html'):
            text=f.read_text(encoding='utf-8').replace('v0.2','v0.3').replace('300','500')
            f.write_text(text,encoding='utf-8')

coupon='''
## 可选项 B：优惠券，仅评估，未批准制作
- 客户希望查看的可选规格：90 × 50 mm，100 张。独立于已确认的 A5 双面宣传单 500 张，不合并数量，不视为已下单。
- 单/双面、优惠内容与适用条件、有效期、使用方式、纸张克重、色数、工艺均未确认；不自行填写优惠金额或承诺。
- 客户包中的优惠券示意仅用于讨论信息结构，不是定稿或印刷文件。
- 若客户决定采用，需另行确认内容、素材、规格、费用及是否影响交期；现有排版费 800 元是否涵盖优惠券尚未约定，不默认包含，也不擅自加价。
'''
f=c/'客户确认单.md'
f.write_text(f.read_text(encoding='utf-8')+'\n'+coupon,encoding='utf-8')

f=c/'客户确认页.html'
text=f.read_text(encoding='utf-8').replace('已确认的项目与费用','确定项目 A｜宣传单与既有费用安排')
section='''<section class="pending"><h2>可选项目 B｜优惠券 · 未批准制作</h2><p><strong>90 × 50 mm，100 张</strong>，仅供查看与评估，独立于已确认的 500 张宣传单，不是追加订单。</p><p>单/双面、优惠内容与使用条件、有效期、核销方式、纸张、色数及工艺均待客户确认。不会自行填写优惠额度或日期。</p><p><a href="优惠券可选示意.html">查看优惠券内容结构示意</a>。仅用于讨论，不是印刷文件。</p><p>是否采用、相关设计费用是否包含在现有 800 元排版费中、印刷报价及交期影响均需另行确认；不默认包含或增加收费。</p></section>'''
text=text.replace('<section class="pending"><h2>请继续确认的内容',section+'<section class="pending"><h2>宣传单仍待确认的内容')
f.write_text(text,encoding='utf-8')

(c/'优惠券可选示意.html').write_text('''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>优惠券可选示意 v0.3</title><style>body{font:16px/1.8 'Microsoft YaHei',sans-serif;margin:28px;color:#263c32;background:#f1f3ef}main{max-width:760px;margin:auto}.card{background:white;border:2px dashed #8d9b8c;aspect-ratio:9/5;padding:24px;box-sizing:border-box;max-width:540px}.slot{border:1px solid #ccc;padding:8px;margin:10px 0;font-size:14px}a{color:#245c46}</style><main><h1>可选优惠券｜未批准制作</h1><p>意向规格 90 × 50 mm，100 张。仅按外形比例展示信息层级，不是实尺寸印刷稿；单/双面未定，以下也不构成选定面数。</p><div class="card"><strong>优惠券（标题建议，待确认）</strong><div class="slot">品牌/LOGO：待确认素材</div><div class="slot">优惠内容与适用条件：待客户提供</div><div class="slot">有效期、使用方式：待客户提供</div></div><p>所有框内文字均为制作说明，不用于正式券面。纸张、色数、工艺、设计费范围和交期影响均待确认；没有生成优惠码或二维码。</p><p><a href="客户确认页.html">返回客户确认页</a></p></main></html>''',encoding='utf-8')

f=p/'印刷询价草稿.md'
text=f.read_text(encoding='utf-8').replace('|项目|规格或待确认事项|','## 确定项目 A：宣传单规格已确认，尚未批准生产\n\n|项目|规格或待确认事项|')
text+='''
## 可选项目 B：优惠券，独立询价，未批准制作
|项目|规格或待确认事项|
|---|---|
|成品尺寸|90 × 50 mm|
|数量|100 张，仅可选评估，不是生产数量授权|
|面数|单/双面待客户确认；如分别估价，请清楚标注假设|
|内容与文件|优惠内容、使用规则、有效期及核销方式待客户确认，无可生产文件|
|纸张/色数/工艺|均待确认，请给出适用建议，按假设分别列价|
|交期|是否采用尚未确定；请说明制作周期，以及与宣传单合并发货或分开发货的影响|

请将 A（宣传单 500 张）和 B（可选优惠券 100 张）分项报价，分别列明税费、运费、打样及报价假设。B 不得默认并入 A 或计作已批准项目；若提供组合价，也必须同时保留各项价格与成立条件。不要因可选项未确定而默认延后 A 的交付。两项均无生产授权，须取得后续明确确认后才能安排生产。
'''
f.write_text(text,encoding='utf-8')

f=i/'执行表.csv'
with f.open(encoding='utf-8',newline='') as stream:
    rows=list(csv.reader(stream))
rows=[[s.replace('300','500') for s in row] for row in rows]
rows += [
 ['优惠券可选规格','90×50毫米100张仅可选且未批准制作','请印厂A独立列价并向客户展示结构示意','设计师与客户','采用决定有明确记录'],
 ['优惠券内容与面数','优惠规则有效期核销方式及单双面均待确认','收集内容并核对全部使用条件','客户','不编造优惠承诺'],
 ['优惠券费用边界','是否计入既有800元排版费尚未约定','采用前另行明确设计费用及印刷报价','客户与设计师','不默认包含或自行加价'],
 ['优惠券生产授权','未批准制作且无生产文件','只评估不制作生产文件不下单','客户','后续明确采用并确认最终样稿规格'],
 ['版本交接','v0.3宣传单500张取代v0.2的300张','只使用当前收件包并保留旧包在内部历史目录','设计师','两类项目和两个收件对象清楚隔离']]
with f.open('w',encoding='utf-8-sig',newline='') as stream:
    csv.writer(stream).writerows(rows)

(i/'推进与交付说明.md').write_text('''# 内部交接 v0.3

## 本次变更与状态
- 确定项目 A：宣传单 A5（148 × 210 mm）双面，500 张；本次数量取代此前 300 张。内容、纸张、色数、工艺及最终样稿仍待确认，不具备生产授权。
- 可选项目 B：优惠券 90 × 50 mm，100 张，仅查看与询价评估，未批准制作。面数、内容、优惠规则、有效期、核销方式、材质工艺及是否采用均未定。客户结构示意不是定稿或生产文件。
- 费用沿用已约定记录：排版费 800 元；定金 200 元尚未付；余款 600 元定稿后支付，实际到账未核实。优惠券是否包含在该设计费中未约定，需先明确，不自行加价或默认包含。
- 设计师只负责设计与询价，不代付印刷费。本次不外发、上传、付款或下单。

## 接手后的顺序
1. 向客户核对宣传单内容与高清 LOGO，取得纸张工艺选择；展位号和联系方式如需刊登应提供准确内容。
2. 印厂 A 将 A、B 分项报价，分别说明假设、税运、打样和周期。可选项目不得默认计入主项，是否影响运输与交期需单列。
3. 补齐收货城市及方式，核实 2026-11-12 前收货的可行性及最晚定稿时间；该日期目前只是期望。
4. 优惠券如决定采用，另确认费用范围、完整内容、面数、材质工艺和样稿。当前仅有示意，不安排制作或生产。
5. 客户批准最终样稿及全部规格后，再按印厂模板检查印刷文件；实际印刷付款与下单由客户另行安排。

## 文件边界及版本
- client_review.zip：客户确认页、确认单、宣传单内容结构预览、优惠券可选示意。解压后打开客户确认页，可离线浏览。
- printer_inquiry.zip：仅印厂 A 印刷询价规格，包含明确分开的 A/B 项目，无客户收费、收款安排或内部成本。
- internal/：执行表与交接、校验记录，不进入收件包。history_v02/ 中的旧包仅用于内部追溯，已被 v0.3 取代，不发送。
- 原始 inputs 不变；旧生成脚本反映历史版本，不应重新运行以覆盖当前材料。本次更新脚本为 update_v03.py（单次迁移用）。
''',encoding='utf-8')
(o/'交付索引.md').write_text('''# 本地交付索引 v0.3
- 客户包：client_review.zip。解压后打开 client_review/ 对应文件“客户确认页.html”（ZIP 内直接为页面文件），离线查看确认事项和可选优惠券示意。
- 印厂 A 包：printer_inquiry.zip，仅含印刷询价草稿。
- 内部交接：internal/推进与交付说明.md、internal/执行表.csv、internal/交付检查记录.txt；旧 v0.2 包在 internal/history_v02/，仅追溯，不对外发送。

确定规格：A5 双面宣传单 500 张。可选：90 × 50 mm 优惠券 100 张，未批准制作，两项分开报价。内容、纸张等未定项目仍待客户确认。无生产 PDF，未外发或下单。
''',encoding='utf-8')
print('v0.3 updated; prior packages retained internally.')
