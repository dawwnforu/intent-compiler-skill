已整理好本地确认与询价材料：

- [客户确认单](outputs/client_review/客户确认单.md)及[内容结构预览](outputs/client_review/内容结构预览.html)：保留 A4 单面、A5 双面两种备选。
- [印厂询价草稿](outputs/printer_inquiry/印刷询价草稿.md)：列明待补规格、报价项目和交期问题。
- 独立预备包：[客户包](outputs/client_review.zip)、[印厂包](outputs/printer_inquiry.zip)。

优先确认尺寸与面数、最终文案和高清 LOGO，再补印量、纸张工艺及收货城市。**2026-11-12 前收货只是期望，尚无印厂承诺。**

已验证原始资料未变、压缩包完整且未混入内部敏感信息。预览尚未做浏览器视觉验收，也不是可生产的印刷文件。未外发、上传或下单。