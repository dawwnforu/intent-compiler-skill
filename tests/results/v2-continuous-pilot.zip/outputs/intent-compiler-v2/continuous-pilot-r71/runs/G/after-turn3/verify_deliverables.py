from pathlib import Path
import zipfile, hashlib, json
r=Path(__file__).resolve().parent
o=r/'outputs'
b=json.loads((o/'internal/原始资料校验.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in b.items())
for name in ['client_review','printer_inquiry']:
    with zipfile.ZipFile(o/(name+'.zip')) as z:
        assert z.testzip() is None
        assert sorted(z.namelist())==sorted(p.name for p in (o/name).iterdir() if p.is_file())
        for f in z.namelist():
            data=z.read(f)
            assert data==(o/name/f).read_bytes()
            assert not any(s in data for s in [b'PRIVATE_COST',b'INTERNAL_PHONE',b'OTHER_CLIENT',b'attempts.jsonl',b'360'])
        print(name, 'PASS')
printer=(o/'printer_inquiry/印刷询价草稿.md').read_text(encoding='utf-8')
assert all(s not in printer for s in ['800','200','600','360','定金','余款','排版费','PRIVATE_COST','INTERNAL_PHONE','OTHER_CLIENT'])
assert '500' in printer and 'A5' in printer and 'A4' not in printer and '300' not in printer
assert all(s in printer for s in ['90 × 50 mm','100 张','未批准制作','分项报价','单/双面待客户确认'])
page=(o/'client_review/客户确认页.html').read_text(encoding='utf-8')
assert all(s in page for s in ['800','200','600','尚未支付','500','A5','90 × 50 mm','100 张','未批准制作'])
assert 'http://' not in page and 'https://' not in page and '<script' not in page
assert (o/'client_review/内容结构预览.html').is_file()
assert 'A4' not in (o/'client_review/内容结构预览.html').read_text(encoding='utf-8')
import csv
with (o/'internal/执行表.csv').open(encoding='utf-8-sig',newline='') as f:
    rows=list(csv.reader(f))
assert all(len(row)==5 for row in rows)
from html.parser import HTMLParser
from urllib.parse import unquote
class OfflineCheck(HTMLParser):
    def handle_starttag(self,tag,attrs):
        assert tag not in ('script','iframe','form')
        for key,value in attrs:
            if key in ('href','src'):
                assert ':' not in value and not value.startswith('//')
                assert (o/'client_review'/unquote(value)).is_file()
for f in (o/'client_review').iterdir():
    text=f.read_text(encoding='utf-8')
    assert '300' not in text and 'v0.2' not in text
    if f.suffix=='.html':
        OfflineCheck().feed(text)
assert sorted(p.name for p in (o/'client_review').iterdir()) == sorted(['客户确认单.md','客户确认页.html','内容结构预览.html','优惠券可选示意.html'])
assert [p.name for p in (o/'printer_inquiry').iterdir()] == ['印刷询价草稿.md']
report='v0.3 验证通过：原始 inputs 文件 SHA-256 未变；两 ZIP 完整性正常、清单与内容一致，收件包仅含预期文件，无内部资料或日志。宣传单统一为 A5 双面 500 张，当前客户和印厂材料无旧300张或v0.2表述。优惠券90×50毫米100张明确为未批准制作可选项；印厂材料要求分项报价，面数待确认。印厂材料未含客户收费金额、排版费、定金余款或内部敏感标记。客户HTML无脚本、表单或外部资源，全部本地链接存在。执行表CSV均为五列。旧包仅存内部history_v02追溯。HTML仅做源码和链接检查，未进行浏览器视觉验收；不是印刷文件。未外发、上传、付款或下单。\n'
(o/'internal/交付检查记录.txt').write_text(report,encoding='utf-8')
print('Input preservation and recipient isolation PASS')
