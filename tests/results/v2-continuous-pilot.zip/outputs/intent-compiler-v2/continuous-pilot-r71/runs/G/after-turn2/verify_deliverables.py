from pathlib import Path
import zipfile, hashlib, json
r=Path(__file__).resolve().parent
o=r/'outputs'
b=json.loads((o/'internal/原始资料校验.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in b.items())
for name in ['client_review','printer_inquiry']:
    with zipfile.ZipFile(o/(name+'.zip')) as z:
        assert z.testzip() is None
        assert sorted(z.namelist())==sorted(p.name for p in (o/name).iterdir() if p.is_file())
        for f in z.namelist():
            data=z.read(f)
            assert data==(o/name/f).read_bytes()
            assert not any(s in data for s in [b'PRIVATE_COST',b'INTERNAL_PHONE',b'OTHER_CLIENT',b'attempts.jsonl',b'360'])
        print(name, 'PASS')
printer=(o/'printer_inquiry/印刷询价草稿.md').read_text(encoding='utf-8')
assert all(s not in printer for s in ['800','200','600','360','定金','余款','排版费','PRIVATE_COST','INTERNAL_PHONE','OTHER_CLIENT'])
assert '300' in printer and 'A5' in printer and 'A4' not in printer
page=(o/'client_review/客户确认页.html').read_text(encoding='utf-8')
assert all(s in page for s in ['800','200','600','尚未支付','300','A5'])
assert 'http://' not in page and 'https://' not in page and '<script' not in page
assert (o/'client_review/内容结构预览.html').is_file()
assert 'A4' not in (o/'client_review/内容结构预览.html').read_text(encoding='utf-8')
import csv
with (o/'internal/执行表.csv').open(encoding='utf-8',newline='') as f:
    rows=list(csv.reader(f))
assert all(len(row)==5 for row in rows)
report='v0.2 验证通过：原始 inputs 文件 SHA-256 未变；两 ZIP 完整性正常、清单与内容一致；未混入内部敏感标记或打包日志。印厂材料不含客户费用金额、定金余款、排版费或内部成本，仅保留 A5 双面 300 张及相关询价事项。客户页正确记录费用和未付款状态，无联网资源或脚本，本地预览链接存在；旧 A4 备选已移除。执行表 CSV 各行均为五列。HTML 已做源码检查，未进行浏览器视觉验收；非印刷文件。未执行任何外部发送或下单。\n'
(o/'internal/交付检查记录.txt').write_text(report,encoding='utf-8')
print('Input preservation and recipient isolation PASS')
