from pathlib import Path
from html.parser import HTMLParser
import csv, hashlib, io, json, re, zipfile

root = Path(__file__).resolve().parents[3]
v2 = root / 'outputs/v2'
original = json.loads((root / 'outputs/internal/input-hashes.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root / p).read_bytes()).hexdigest() == h for p, h in original.items())
private = (root / 'inputs/03-internal.md').read_text(encoding='utf-8')
markers = re.findall(r'(?:PRIVATE_COST|INTERNAL_PHONE|OTHER_CLIENT)\S+', private)
assert len(markers) == 3

class CheckHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.text = []
        self.links = []
        self.stack = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        assert tag not in ('script', 'iframe', 'form', 'object', 'embed')
        self.links += [value for key, value in attrs.items() if key in ('src', 'href')]
        if tag not in ('meta', 'br', 'hr', 'img', 'input', 'link'):
            self.stack.append(tag)
    def handle_endtag(self, tag):
        assert self.stack.pop() == tag
    def handle_data(self, data):
        self.text.append(data)

html = (v2 / 'client/confirmation.html').read_text(encoding='utf-8')
parser = CheckHTML()
parser.feed(html)
assert not parser.stack and not parser.links
assert not re.search(r'url\s*\(|@import|https?://', html, re.I)
for value in ('800 元', '200 元', '600 元', '尚未支付', '300 张', 'A5 双面', '待确认'):
    assert value in html
assert 200 + 600 == 800
printer = (v2 / 'printer-A/print-spec.md').read_text(encoding='utf-8')
for prohibited in markers + ['800', '200', '600', '360', '定金', '余款', '排版费', '内部成本', '客户收费']:
    assert prohibited not in printer
assert all(x in printer for x in ('148 × 210', '300 张', '双面', '待客户选择'))

table = v2 / 'internal/execution.csv'
raw = table.read_bytes()
if not raw.startswith(b'\xef\xbb\xbf'):
    table.write_bytes(b'\xef\xbb\xbf' + raw)
rows = list(csv.reader(io.StringIO(table.read_text(encoding='utf-8-sig'))))
assert len(rows) == 16 and all(len(row) == 7 for row in rows)
archives = {}
for folder, filename in [('client', 'client-review.zip'), ('printer-A', 'printer-A-inquiry.zip')]:
    sources = {p.relative_to(v2 / folder).as_posix(): p for p in (v2 / folder).rglob('*') if p.is_file()}
    with zipfile.ZipFile(v2 / filename) as z:
        assert set(z.namelist()) == set(sources) and z.testzip() is None
        for name, source in sources.items():
            assert z.read(name) == source.read_bytes()
            assert all(m not in z.read(name).decode('utf-8') for m in markers)
        archives[filename] = z.namelist()
report = {'checked': '2026-10-19', 'original_inputs_unchanged': True,
          'html_balanced_and_no_external_resources': True, 'browser_rendering': 'not tested; no browser automation available',
          'fees_reconciled': True, 'execution_table_tasks': len(rows)-1,
          'printer_fee_and_private_scan': 'passed', 'archive_members_and_crc': archives,
          'external_actions': 'none', 'paper_and_copy': 'pending customer confirmation'}
(v2 / 'internal/verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=True, indent=2))
