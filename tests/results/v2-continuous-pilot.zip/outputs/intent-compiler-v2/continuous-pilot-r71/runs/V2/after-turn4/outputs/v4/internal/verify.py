from pathlib import Path
from html.parser import HTMLParser
import csv, hashlib, json, re, zipfile

root=Path(__file__).resolve().parents[3]
v4=root/'outputs/v4'
baseline=json.loads((v4/'internal/preserved-hashes.json').read_text(encoding='utf-8'))
assert len(baseline)>4
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in baseline.items())
private=(root/'inputs/03-internal.md').read_text(encoding='utf-8')
markers=re.findall(r'(?:PRIVATE_COST|INTERNAL_PHONE|OTHER_CLIENT)\S+',private)
assert len(markers)==3
client=(v4/'client/confirmation.html').read_text(encoding='utf-8')
printer=(v4/'printer-B/print-spec.md').read_text(encoding='utf-8')
for text in (client,printer):
    assert all(x in text for x in ('300 张','148 × 210','双面','v0.4','印厂 B'))
    for forbidden in markers+['优惠券','500','90 × 50','90×50','印厂 A','印厂A','sources/','print-archive','上传','旧版 300']:
        assert forbidden not in text, forbidden
    assert not re.search(r'v0\.[123]',text)
assert all(x in client for x in ('800 元','200 元','600 元','尚未支付','在定稿后支付','不代付印刷费','内容与纸张仍待确认'))
for forbidden in ['800','200','600','360','排版费','定金','余款','内部成本','客户收费']:
    assert forbidden not in printer
assert '交期须收到定稿后再确认' in printer and '未提供实际价格或交期承诺' in printer
class OfflineHTML(HTMLParser):
    def __init__(self): super().__init__(); self.stack=[]
    def handle_starttag(self,tag,attrs):
        assert tag not in ('script','iframe','form','object','embed')
        assert not any(k in ('src','href') for k,v in attrs)
        if tag not in ('meta','br','hr','input','link','img'): self.stack.append(tag)
    def handle_endtag(self,tag): assert self.stack.pop()==tag
p=OfflineHTML();p.feed(client);assert not p.stack
assert not re.search(r'url\s*\(|@import|https?://',client,re.I)
rows=list(csv.reader((v4/'internal/execution.csv').open(encoding='utf-8-sig',newline='')))
assert len(rows)==20 and all(len(r)==7 for r in rows)
assert all('500' not in cell for row in rows for cell in row)
packages=v4/'final-packages'
allowed={'client-review-v0.4.zip':('client','confirmation.html'),'printer-B-inquiry-v0.4.zip':('printer-B','print-spec.md')}
assert {p.name for p in packages.iterdir()}==set(allowed)
results={}
for filename,(folder,member) in allowed.items():
    with zipfile.ZipFile(packages/filename) as z:
        assert z.namelist()==[member] and z.testzip() is None
        assert z.read(member)==(v4/folder/member).read_bytes()
    results[filename]={'only_member':member,'crc_and_source_match':True,'sha256':hashlib.sha256((packages/filename).read_bytes()).hexdigest()}
report={'date':'2026-10-19','preserved_inputs_and_historical_files':len(baseline),'all_preserved_hashes_unchanged':True,'current_quantity':300,'coupon':'withdrawn; absent from recipient files','printer':'B only','recipient_isolation':'passed; no raw sources, internal or historical files','packages':results,'html_offline_structure':'passed','browser_rendering':'not tested','external_actions':'none'}
(v4/'internal/verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True,indent=2))
