from pathlib import Path
import csv, hashlib, io, json

root = Path(__file__).resolve().parents[3]
v2, v4 = root/'outputs/v2', root/'outputs/v4'
for folder in ('client', 'printer-B', 'internal', 'final-packages'):
    (v4/folder).mkdir(parents=True, exist_ok=True)
baseline = {}
for directory in (root/'inputs', root/'outputs'):
    for p in directory.rglob('*'):
        if p.is_file() and not p.is_relative_to(v4):
            baseline[p.relative_to(root).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
(v4/'internal/preserved-hashes.json').write_text(json.dumps(baseline,indent=2),encoding='utf-8')

html = (v2/'client/confirmation.html').read_text(encoding='utf-8').replace('v0.2','v0.4')
html = html.replace('规格及设计费用已确认，内容与纸张仍待确认。','本次项目：A5 双面宣传单 300 张。规格及设计费用已确认，内容与纸张仍待确认。')
html = html.replace('印厂尚未确认可行性，不是已承诺交期。','印厂 B 表示收到定稿后再确认交期；目前不是已承诺交期。')
html = html.replace('<tr><td>期望收货</td>', '<tr><td>询价对象</td><td>印厂 B，尚未取得实际报价。</td></tr>\n<tr><td>期望收货</td>')
html = html.replace('v0.4 取代此前规格与数量未定的确认草稿。','以本次 v0.4 为准；本次范围仅为上述宣传单。')
(v4/'client/confirmation.html').write_text(html,encoding='utf-8')

printer = (v2/'printer-A/print-spec.md').read_text(encoding='utf-8').replace('印厂 A','印厂 B').replace('v0.2','v0.4')
printer = printer.replace('## 已确定规格','## 本次唯一项目：宣传单已确定规格')
printer = printer.replace('## 未定条件','''## 对贵方参考说明的理解
贵方说明可按 A5 双面报价，纸张及表面处理不同会影响价格；交期须收到定稿后再确认。目前未提供实际价格或交期承诺。本次仅准备询价，尚未发送。

## 未定条件''')
printer = printer.replace('本材料取代此前规格与数量未定的询价草稿。','本次询价以此 v0.4 为准，仅涉及上述宣传单，无其他附加产品。')
(v4/'printer-B/print-spec.md').write_text(printer,encoding='utf-8')

rows = list(csv.reader(io.StringIO((v2/'internal/execution.csv').read_text(encoding='utf-8-sig'))))
rows = [[c.replace('印厂A','印厂B').replace('本会话补充确认','本会话最新确认') for c in row] for row in rows]
rows += [
 ['撤回项目','优惠券','用户','已撤回，完全不做','不设计、不询价、不制作','不得恢复为可选项；最终收件文件不包含该产品','仅在内部历史保留撤回记录'],
 ['收件人变更','印厂A停止合作，改印厂B','用户','已确认','本次只准备B询价材料','A旧文件及包保留历史，不得使用或放入最终包','不向A提供本次材料'],
 ['交期核实','印厂B参考说明','印厂B/设计师','待定稿后确认','目前没有实际报价或承诺','纸张和表面处理影响报价；定稿后再次核实交期','11月12日前收货仍仅期望'],
 ['交付隔离','核对最终包白名单','设计师','本地已打包待校验','仅client-review-v0.4.zip、printer-B-inquiry-v0.4.zip','校验包内文件、数量、版本和隐私；见verification.json','不得打包outputs根目录或历史目录']]
with (v4/'internal/execution.csv').open('w',encoding='utf-8-sig',newline='') as f:
    csv.writer(f).writerows(rows)
