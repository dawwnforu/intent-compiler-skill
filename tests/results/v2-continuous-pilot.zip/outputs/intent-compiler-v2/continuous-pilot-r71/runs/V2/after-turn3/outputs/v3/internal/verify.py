from pathlib import Path
import csv, hashlib, json, re, zipfile
from html.parser import HTMLParser

root = Path(__file__).resolve().parents[3]
v3 = root/'outputs/v3'
hashes = json.loads((root/'outputs/internal/input-hashes.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest() == h for p,h in hashes.items())
markers = re.findall(r'(?:PRIVATE_COST|INTERNAL_PHONE|OTHER_CLIENT)\S+', (root/'inputs/03-internal.md').read_text(encoding='utf-8'))
assert len(markers) == 3
class OfflineHTML(HTMLParser):
    def __init__(self):
        super().__init__(); self.stack=[]
    def handle_starttag(self, tag, attrs):
        assert tag not in ('script','form','iframe','embed','object')
        assert not any(k in ('src','href') for k,v in attrs)
        if tag not in ('meta','br','hr','link','img','input'): self.stack.append(tag)
    def handle_endtag(self, tag):
        assert self.stack.pop() == tag
client = (v3/'client/confirmation.html').read_text(encoding='utf-8')
printer = (v3/'printer-A/print-spec.md').read_text(encoding='utf-8')
p=OfflineHTML(); p.feed(client); assert not p.stack
assert not re.search(r'url\s*\(|@import|https?://',client,re.I)
for text in (client,printer):
    assert all(x in text for x in ('500 张','100 张','90 × 50','未批准制作','v0.3'))
    assert not re.search(r'300\s*张', text.replace('旧版 300 张',''))
    assert all(marker not in text for marker in markers)
for token in ('800','200','600','360','排版费','定金','余款','内部成本','客户收费'):
    assert token not in printer
assert all(x in client for x in ('800 元','200 元','600 元','尚未支付','不默认包含优惠券新增设计'))
assert '不并入宣传单 500 张基础总价' in printer
rows=list(csv.reader((v3/'internal/execution.csv').open(encoding='utf-8-sig',newline='')))
assert len(rows)==19 and all(len(r)==7 for r in rows)
assert not any('300张' in c for row in rows for c in row)
archives={}
for directory,archive in [('client','client-review.zip'),('printer-A','printer-A-inquiry.zip')]:
    expected={p.relative_to(v3/directory).as_posix():p for p in (v3/directory).rglob('*') if p.is_file()}
    with zipfile.ZipFile(v3/archive) as z:
        assert set(z.namelist())==set(expected) and z.testzip() is None
        for name,path in expected.items(): assert z.read(name)==path.read_bytes()
        archives[archive]={'members':z.namelist(),'sha256':hashlib.sha256((v3/archive).read_bytes()).hexdigest()}
report={'date':'2026-10-19','original_inputs_unchanged':True,'main_quantity':500,'optional_coupon':{'quantity':100,'size_mm':[90,50],'approved_for_production':False},'archives':archives,'recipient_isolation':'passed','html_structure_and_offline_resources':'passed','browser_rendering':'not tested','execution_tasks':len(rows)-1,'external_actions':'none'}
(v3/'internal/verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True,indent=2))
