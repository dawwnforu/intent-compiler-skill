from pathlib import Path
import csv, io

root = Path(__file__).resolve().parents[3]
v2, v3 = root/'outputs/v2', root/'outputs/v3'
for name in ('client', 'printer-A', 'internal'):
    (v3/name).mkdir(parents=True, exist_ok=True)
html = (v2/'client/confirmation.html').read_text(encoding='utf-8')
html = html.replace('v0.2', 'v0.3').replace('300 张', '500 张')
html = html.replace('规格及设计费用已确认，内容与纸张仍待确认。', '宣传单已确认 A5 双面、500 张；优惠券仅为可选项，未批准制作。内容与纸张仍待确认。')
html = html.replace('<h2>现有文字，请审阅</h2>', '''<h2>可选项：优惠券（未批准制作）</h2>
<p class="notice"><strong>拟比较规格：100 张，90 × 50 毫米。</strong>仅供了解可选方案与单独询价，不计入宣传单 500 张，不代表已委托设计、批准制作或下单。</p>
<p>优惠券单双面、纸张、克重、色彩、工艺和内容均待确认。优惠金额或折扣、适用范围、使用期限、使用规则及是否需要编号等均未提供，不自行编造。请先决定是否采纳；采纳后再明确内容、规格及新增设计费用安排。现有宣传单排版费 800 元及付款安排保持原约定，不默认包含优惠券新增设计。</p>
<h2>现有宣传单文字，请审阅</h2>''')
html = html.replace('补齐内容后制作 A5 双面版式预览；', '宣传单补齐内容后制作 A5 双面版式预览；优惠券在另行批准前不开始制作。')
html = html.replace('v0.3 取代此前规格与数量未定的确认草稿。', '本版宣传单 500 张取代旧版 300 张。优惠券仅可选，不合并为已批准项目。以 v0.3 为准。')
(v3/'client/confirmation.html').write_text(html, encoding='utf-8')

printer = (v2/'printer-A/print-spec.md').read_text(encoding='utf-8')
printer = printer.replace('v0.2', 'v0.3').replace('300 张', '500 张').replace('300张', '500张')
printer = printer.replace('## 已确定规格', '## 主项：宣传单已确定规格')
printer = printer.replace('## 未定条件', '''## 可选项：优惠券，仅单独询价，未批准制作
| 项目 | 拟比较条件 |
|---|---|
| 成品尺寸 | 90 × 50 mm |
| 数量 | 100 张，独立于宣传单 500 张 |
| 状态 | 可选，未批准制作，不是已确定生产项目 |
| 双单面、纸张/克重、色彩、工艺 | 均待确认；如提供比较方案，请逐项列明假设 |
| 内容与文件 | 未确定，无付印文件 |
| 交期 | 是否需要与宣传单同期交付尚未确认；请单列所需时间 |

请将优惠券 100 张作为可选报价单独列出，不并入宣传单 500 张基础总价，不默认为已选方案。条件未齐时仅提供注明假设的参考方案，最终报价以客户选定条件为准。无需设计或生产优惠券。

## 主项未定条件''')
printer = printer.replace('1. 500 张各纸张/工艺方案', '1. 宣传单 500 张各纸张/工艺方案')
printer = printer.replace('| 待印厂填写 | 待报价 | 待报价 | 未报价 | 未报价 | 未确认 | 未确认 | 未确认 |', '| 宣传单主项 | 待报价 | 待报价 | 未报价 | 未报价 | 未确认 | 未确认 | 未确认 |')
printer = printer.replace('请勿据本规格开印。', '''### 优惠券可选报价（不计入主项总价）
| 数量/尺寸 | 双单面/纸种/克重/色彩/工艺假设 | 可选项单独总价 | 税/运/打样费用及共用费用处理 | 所需时间/有效期 |
|---|---|---|---|---|
| 100 张 / 90 × 50 mm | 待说明，均未批准 | 未报价 | 待说明；不能重复计收或隐含合并 | 未确认 |

请勿据本规格开印。''')
printer = printer.replace('本材料取代此前规格与数量未定的询价草稿。', '宣传单数量本版为 500 张，取代旧版 300 张。本次新增优惠券仅可选询价，未批准制作。以 v0.3 为准。')
(v3/'printer-A/print-spec.md').write_text(printer, encoding='utf-8')

rows = list(csv.reader(io.StringIO((v2/'internal/execution.csv').read_text(encoding='utf-8-sig'))))
rows = [[cell.replace('300张','500张').replace('本会话补充确认','本会话最新确认') for cell in row] for row in rows]
rows += [
 ['可选项','优惠券是否采纳','客户','未批准制作','100张；90×50mm','仅单独询价，先取得明确采纳决定','不得混入宣传单主项或启动设计生产'],
 ['可选项','优惠券具体内容与规格','客户','待确认','单双面/纸张/克重/色彩/工艺均未定','若采纳，补齐优惠额度、适用范围、期限、规则及编号需求','不得编造优惠承诺；同期交付也未确认'],
 ['可选项','优惠券新增设计范围及费用','设计师/客户','未约定','不默认包含在现有800元内','批准采纳后另行明确范围和收费，不擅改原收费','不因询价视为委托制作']]
with (v3/'internal/execution.csv').open('w',encoding='utf-8-sig',newline='') as f:
    csv.writer(f).writerows(rows)
