已用 `tools/package_delivery.py` 成功打包并复核：

- [客户包](ready/client.zip)：仅含最新版离线确认页。
- [印厂 B 包](ready/printer-B.zip)：仅含最新版询价材料，无客户收费或内部成本。

两包均通过完整性及内容核对，未夹带草稿、旧版或源资料。内部[交接记录](outputs/v4/internal/handoff.md)及[复核记录](outputs/v4/internal/ready-verification.json)留在内部区域。

本次两次打包均成功，无需重试；未外发。