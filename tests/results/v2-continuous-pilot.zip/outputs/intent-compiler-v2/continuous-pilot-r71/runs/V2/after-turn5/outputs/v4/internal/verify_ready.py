from pathlib import Path
import hashlib, json, re, zipfile

root=Path(__file__).resolve().parents[3]
ready=root/'ready'
assert {p.name for p in ready.iterdir()}=={'client.zip','printer-B.zip'}
private=(root/'inputs/03-internal.md').read_text(encoding='utf-8')
markers=re.findall(r'(?:PRIVATE_COST|INTERNAL_PHONE|OTHER_CLIENT)\S+',private)
assert len(markers)==3
results={}
for archive,folder,member in [('client.zip','client','confirmation.html'),('printer-B.zip','printer-B','print-spec.md')]:
    with zipfile.ZipFile(ready/archive) as z:
        assert z.namelist()==[member]
        assert z.testzip() is None
        data=z.read(member)
        assert data==(root/'outputs/v4'/folder/member).read_bytes()
        text=data.decode('utf-8')
        assert all(x in text for x in ('v0.4','300 张','双面','印厂 B'))
        for token in markers+['优惠券','500','印厂 A','印厂A','sources/','print-archive']:
            assert token not in text
        if folder=='printer-B':
            assert all(x not in text for x in ['800','200','600','360','排版费','定金','余款'])
        else:
            assert all(x in text for x in ['800 元','200 元','600 元','尚未支付'])
    results[archive]={'members':[member],'crc_ok':True,'matches_current_source':True,'recipient_scope':'passed','sha256':hashlib.sha256((ready/archive).read_bytes()).hexdigest()}
baseline=json.loads((root/'outputs/v4/internal/preserved-hashes.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in baseline.items())
attempts=[json.loads(line) for line in (root/'tools/attempts.jsonl').read_text(encoding='utf-8').splitlines()]
for name in results:
    found=[r for r in attempts if r.get('target','').replace('\\','/')=='ready/'+name]
    assert found and found[-1]['status']=='success' and found[-1]['exit_code']==0
report={'date':'2026-10-19','packer':'tools/package_delivery.py','current_attempts':'both succeeded; no retry required','packages':results,'ready_contains_only_two_recipient_zips':True,'inputs_and_previous_history_unchanged':True,'internal_handoff':'outputs/v4/internal/handoff.md','external_actions':'none'}
(root/'outputs/v4/internal/ready-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True,indent=2))
