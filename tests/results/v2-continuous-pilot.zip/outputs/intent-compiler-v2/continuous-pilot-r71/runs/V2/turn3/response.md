已更新为 v0.3，并分别打包：

- [客户包](outputs/v3/client-review.zip)：含可离线打开的确认页。
- [印厂 A 包](outputs/v3/printer-A-inquiry.zip)：仅印刷规格，不含客户收费或内部成本。
- [内部交接](outputs/v3/internal/handoff.md)及[执行表](outputs/v3/internal/execution.csv)。

明确区分：**宣传单 A5 双面、500 张已确认；优惠券 100 张、90 × 50 毫米仅为可选询价项，未批准制作**，报价单列，不并入主项。

内容、纸张和工艺继续待确认。已核对包内文件及信息隔离，原件与旧版保留；未外发、付款或下单。