已实际解压并核查当前两份包：

- [客户包](ready/client.zip)：仅含离线确认页。
- [印厂 B 包](ready/printer-B.zip)：仅含询价规格，无客户收费或内部信息。

内容均为 **A5 双面、300 张，无优惠券**，没有旧版或源资料，无需改包。已修正内部执行表中过时的包名及“待校验”状态。

[同事交接入口](outputs/v4/internal/handoff.md)已列明当前决定、待办顺序及有效文件位置；[实际解压核查记录](outputs/v4/internal/recipient-audit.json)留在内部。浏览器显示未实测。未执行任何外部操作。