from pathlib import Path
import csv, hashlib, io, json, zipfile

root=Path(__file__).resolve().parents[3]
internal=root/'outputs/v4/internal'
rows=list(csv.reader(io.StringIO((internal/'execution.csv').read_text(encoding='utf-8-sig'))))
for row in rows:
    if row[0]=='交付隔离':
        row[3]='已核查实际解压内容'
        row[4]='仅ready/client.zip、ready/printer-B.zip'
        row[5]='实际解压、内容、CRC及字节比对通过；见recipient-audit.json'
with (internal/'execution.csv').open('w',encoding='utf-8-sig',newline='') as f:
    csv.writer(f).writerows(rows)

results={}
for archive,folder,member in [('client.zip','client','confirmation.html'),('printer-B.zip','printer-B','print-spec.md')]:
    package=root/'ready'/archive
    target=internal/'recipient-check'/folder
    target.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(package) as z:
        assert z.namelist()==[member] and z.testzip() is None
        z.extract(member,target)
    extracted=target/member
    data=extracted.read_bytes()
    assert data==(root/'outputs/v4'/folder/member).read_bytes()
    text=data.decode('utf-8')
    assert '\ufffd' not in text
    assert all(x in text for x in ['v0.4','300 张','148 × 210','双面','印厂 B'])
    assert all(x not in text for x in ['优惠券','500','sources/','印厂 A','印厂A','print-archive'])
    private=(root/'inputs/03-internal.md').read_text(encoding='utf-8')
    import re
    markers=re.findall(r'(?:PRIVATE_COST|INTERNAL_PHONE|OTHER_CLIENT)\S+',private)
    assert len(markers)==3 and all(m not in text for m in markers)
    if folder=='client':
        assert all(x in text for x in ['800 元','200 元','600 元','尚未支付','在定稿后支付','不代付印刷费','内容与纸张仍待确认'])
        assert all(x not in text for x in ['<script','<form','<iframe','src=','href='])
        assert not re.search(r'url\s*\(|@import|https?://',text,re.I)
    else:
        assert all(x not in text for x in ['800','200','600','360','定金','余款','排版费','内部成本'])
        assert '交期须收到定稿后再确认' in text
    results[archive]={'extracted_member':member,'extracted_path':extracted.relative_to(root).as_posix(),'crc_ok':True,'source_bytes_match':True,'current_decisions_and_recipient_scope':'passed','package_sha256':hashlib.sha256(package.read_bytes()).hexdigest()}
assert {p.name for p in (root/'ready').iterdir()}=={'client.zip','printer-B.zip'}
report={'date':'2026-10-19','method':'Read and extract actual ready ZIPs into internal check directories; inspect decoded files and compare bytes','packages':results,'recipient_file_changes':'none needed; current packages retained','internal_correction':'execution.csv package paths and verification status updated; handoff entry points and next actions added','browser_rendering':'not tested; offline dependencies checked','external_actions':'none'}
(internal/'recipient-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True,indent=2))
