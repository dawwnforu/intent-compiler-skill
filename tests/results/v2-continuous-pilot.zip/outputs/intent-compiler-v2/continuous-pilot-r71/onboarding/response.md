已更新 [client.zip](outputs/client.zip) 和 [internal.md](outputs/internal.md)。

拍摄时间统一为 **2026年11月6日14:00—17:00**，原上午时段作废；客户页面及回复单不再询问下午请求。其他已确认内容和待定事项保留。

已核验压缩包实际内容与内部一致，原始 inputs 未修改。仅在本地处理，未外发、上传、付款或发布。