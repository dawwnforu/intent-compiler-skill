Intent Compiler · 双语交付演示 / bilingual deliverable demo

解压整个文件夹，打开 pilot/demo/index.html。不要只移动HTML。
Extract the complete directory and open pilot/demo/index.html.

这是只读演示，不是Skill安装包，不会自动运行Agent或收集反馈。
This is a read-only demo, not a Skill installer; it runs no agent and collects no feedback.

实际Windows双击/原生下载尚未验证；本机HTTP浏览器与原处理器检查单独记录。
Native file opening/download remain unverified; local HTTP browser and handler checks are separate.

初次使用可看 pilot/START_HERE.md；实际免费商品：
https://www.agensi.io/skills/intent-compiler-everyday-ideas-to-usable-work

保留MIT与来源。本例为内部合成任务，四组均通过，不证明独有优势或长期记忆。
See SOURCE.json and LICENSE. All four arms passed this synthetic case; no unique-gain or long-term-memory claim.
