# 兼容状态：按产物与版本记录

**2026-10-24更新回执（R98）：** 用户授权后同一Agensi商品提交cefba82；只读状态为平台1.1／live／approved／Free／pending_update:null，公开介绍显示新来源。仅验证更新状态与公开元数据，新包渠道加载／业务未运行；下方R92–R94仍是af3d2c8，不静默升级为新版兼容结果。首批改用公开或自制素材专业任务，外部参与仍为0；不增加宿主支持声明。[回执及边界](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/commercial/SUBMISSION.md)。

**2026-10-24领取补验（R96）：** 当前af3d2c8固定GitHub文件页已实际点击下载，4.371秒取得文件；37,504字节、SHA-256、25成员及声明哈希与R82获取一致。保留过严许可证字段比较的核验器失败，只修检查、不改包。此为本机浏览器领取，不新增安装/发现/业务兼容或外部试用者收件结论。[详细记录](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/tests/v2-resource-paths.md#r96--actual-browser-acquisition-of-af3d2c8)。

**2026-10-24 cefba82本地回归（R95）：** 已上传的更新预览未提交审核，公开默认仍为af3d2c8。新段落在一次已曝光R92任务的项目内实际运行中被读取，生成中文客户ZIP和独立内部表，开发者另行字节/操作检查及桌面浏览器打开通过。不是Agensi新包验证、未见任务或减少提示的因果证据；不将下方历史包升级。[范围、成本与限制](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/tests/v2-encoding-regression.md)。

**2026-10-24续验（R93–R94）：** 已实际中断，并在同一仍运行的临时Codex会话内继续；最终客户ZIP和内部表时间一致，原始资料及其他决定保留，独立解压/隐私/浏览器检查通过。R93误用磁盘恢复接口的失败保留，R94只修正评测器调用，不改Skill。完整MIT、SVG和脚本内容可经连接读取并匹配原包；脚本执行及进程重启恢复未验。这些运行用已上架af3d2c8，没有使用新编码段落；后续上传预览不改变旧实验来源。不外推无干预首交、其他宿主或真实用户效果。[完整记录与成本](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/tests/v2-agensi-continuation.md)。

**2026-10-24 Agensi（R92）：** af3d2c8已免费公开、匿名可见且可搜索。用户明确批准启用后，实际Codex gpt-6.1-sol/low通过MCP加载核心和引用；独立核对渠道来源/引用与原包一致。首次中文交付失败，一次开发者编码提示后，修复包通过独立字节、实际Python解压、隐私和浏览器检查；不是无干预成功或用户提示减少。原定继续修改未执行，原线程未恢复；可选脚本渠道执行、原生解压/双击和其他宿主仍未验。[完整失败与成本](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/tests/v2-agensi-delivery.md)。平台条目1.0与源清单0.2.0分开；本分支新编码核验方法未上传，旧包和旧证据保持原版本。

**2026-10-24新包（R82）：** af3d2c8的25个成员在新隔离项目全部实际解压并核对字节，安装后可选HTML检查器五项测试通过；本机CLI版本查询仍为0.163.0-alpha.10.2，保留临时别名清理警告。**本包未重跑发现、模型业务或浏览器下载**；下方R80发现/选用和R70/R71业务仍是各自旧包/快照的证据，不能升级成新包全流程验收。其他宿主、Agensi连接、外部收件和采用仍未验证。[工具与打包记录](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/tests/v2-resource-paths.md)。

**2026-10-21启动跟进（R80）：** 新2881c73包只改变README和已有`interface.display_name`。真实继承用户配置的发现中，旧版和项目候选均启用；原先显示名相同，修复后候选标签可区分。一例gpt-6.1-sol明确路径启动实际读取新包内SKILL/SOURCE并写入正确回执；不是UI选择器点击、自动优先级或业务质量验证。新包尚无浏览器下载/外部收件证据；旧R79下载事实不移用。正式安装、核心和旧包未替换，其他宿主声明不变。[分项记录](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/tests/v2-submission-candidate.md#r80-distinguish-the-project-candidate-from-a-same-name-release)。


**2026-10-21独立候选包：** [R79](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/tests/v2-submission-candidate.md)的abef76f ZIP已在全新项目实际解压，24个源文件与包逐字节一致，Codex当前宿主实际forceReload发现及唯一项目路径选用检查通过。固定承载提交cdb385d的程序化获取和浏览器实际下载均核对字节/哈希；外部用户收件未知。未从新包追加业务生成；其运行文本与R78在CRLF/LF归一后相同，不是历史快照逐字节相同。静态／获取／安装／发现／R78行为／平台连接分开，不升级Claude、Cursor、Copilot或Agensi的声明。以下保留旧239553d试用包及2026-10-19的各自证据。

R72只补实际领取和复制检查，不重新推导宿主兼容性。固定239553d ZIP由GitHub连接器取得54,242字节，与已推送Git blob及本机包一致；外层/客户ZIP校验及新空项目复制通过。公开curl请求限时失败，浏览器下载仍只有R71失败记录，外部试用者尚未收到/安装；这些状态互不替代。[领取证据](https://github.com/dawwnforu/intent-compiler-skill/blob/beeacef6fe6f484c1aadfd22e48589cbcb6fe35f/tests/v2-pilot-readiness.md)与下列既有宿主业务证据分开。SOURCE.json核心来源c204e14、包所在提交239553d、清单0.2.0为不同标识，不宣称已发布2.0。Codex仍是首批默认；尚无真实用户的其他宿主需求，不另装软件、不重试Claude认证。

共享核心是清单0.2.0／2.0未发布候选，R71 从 c204e14 冻结，运行文件仍与 R70/6d18460 字节一致。这里的“安装”是脚本按说明在新项目复制完整文件夹，不代表非技术用户已独立安装；没有替换个人或正式安装。

| 宿主 | 安装／发现与触发 | 引用与实际工具 | 权限与交付 | 恢复／限制 |
|---|---|---|---|---|
| Codex CLI 0.163.0-alpha.10.2，gpt-6.1-sol/low | R70/R71 实际ZIP复制24个Skill文件并发现；隔离模式 `$intent-compiler` 已验。普通发现会同时列出项目/个人同名版；R71 明确项目文件路径的单次实际业务调用读对版本 | R71 实际读核心、索引、澄清、打印、来源、质量及交互模块；shell/Python实际生成。未强制所有任务加载全部引用 | 同一批准启动方式、子进程workspace-write/禁网；R71 三组六轮均完成本例当前客户/印厂分包，独立检查实际成员、元数据、正文、原件字节及命令；客户页实际浏览器打开 | 三组各6轮，后5轮恢复同一会话；另一次从试用ZIP继续摄影修改。Windows双击/文本编辑器/原生打印、真实用户独立使用和所有模式仍未验；不能由单例推断全面兼容 |
| Claude Code 2.1.201 | 项目 `.claude/skills/intent-compiler` 实际复制，初始化清单出现skill及slash入口 | 尚未进入实际工具执行 | R70 auth status显示已登录但业务401；R71 只读路由元数据确认父进程 `ANTHROPIC_BASE_URL` 指向 api.deepseek.com，Sonnet被环境映射为deepseek-v4-pro[1M] | 这是继承的第三方路由/远端认证阻塞，不是Skill未发现；具体凭据/账户原因未确定。未更改凭据或重试模型，Anthropic Sonnet、恢复及交付仍未验 |
| Cursor／GitHub Copilot | 本轮未找到可调用的对应CLI，不安装新软件 | 未验 | 不宣称支持，不把通用Markdown当适配结果 | 先完成首批用户在Codex路径，再按真实用户宿主需求决定扩展 |
| Agensi1.6.0，经Codex gpt-6.1-sol/low | OAuth、搜索、实际核心/引用调用成功；来源及完整MIT、SVG、脚本内容匹配原包 | R92首交＋曝光修复；R93失败与R94两轮中断/继续分别保留；脚本内容可读，执行未验 | 首交乱码及专业救场不删除；R94最终ZIP/内部表一致，未执行外部资料的备份/上传/通知 | 一次同一临时会话中断后继续已验；进程重启、无干预首交、原生应用/打印、许可关系及外部采用未验 |

Claude 的PowerShell包装脚本受当前执行策略阻止；使用已安装的官方`.cmd`入口能读取版本和启动，不改变执行策略。但本地“已登录”不证明远端凭据有效，也不证明请求解析到期望模型。没有更换凭据、提供商或绕过权限。

如需继续 Claude，由账户持有人先选定预期提供商并按其正常方式完成认证/配置，不在反馈中发密钥；之后再单独跑一次合成业务，不能拿当前 DeepSeek 路由当 Sonnet 验证。Cursor/Copilot 本轮再次未发现可调用命令；尚无首批用户的宿主需求证据，暂不扩展安装，不阻塞 Codex 免费试用。

R71 浏览器实际打开三组客户最终页，点击 G 的预览、A 的填写与刷新、摄影回复及新附件链接。A 表单刷新丢失填写，与其提示一致；打印/另存PDF未操作。客户样例TXT在普通HTTP预览中乱码，试用打包时加UTF-8标记后可读；仅此修复已验，不推广为任意文件/浏览器保证。本次浏览器控制禁止 `file:`，未绕过；本地双击仍未验。部分 Windows PowerShell→Python 管道命令损坏中文文件名，当次模型自行修复后完成；不能宣称整个 Windows 工具链无编码问题。

静态格式检查、安装复制、发现/选用、实际业务、接收方操作是分开的证据。首批以已能运行 Codex 的用户开始；普通配置同名时按 README 明确项目文件路径，不要求删除正式安装。裸名称在多版本下的选择仍未验证。

Codex 官方项目路径见[Build skills](https://learn.chatgpt.com/docs/build-skills)；Claude 项目路径见[Skills](https://code.claude.com/docs/en/skills)。文档描述与实际测试分开；不能由格式检查或其他宿主的结果推断本宿主成功。需要工具、模型和账户已经可用；本包不会替你配置付款或提供访问权。
